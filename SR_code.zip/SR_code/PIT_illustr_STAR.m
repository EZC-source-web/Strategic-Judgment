clc;
clear

importfile('C:\Users\ezanettichini\Desktop\SR\Code\Data_q.xls');
y=IIP;
x=[lag(y,1)];

R = 40;
pmax = 4;
%S = 10000;
qn = floor(R^(1/2));
h = 1;
T = length(y);

% Creates matrices to store the forecasts
densforecast = zeros(size(y,1),1)';
densforecast_nl = zeros(size(y,1),1)';
 
   %% COMPUTE PIT 
   
%Set the inputs for function "mrstar.m".
X = [ones(T,1), lag(y,1) lag(y,2) lag(y,3) ];
W = [];
nX = size(X,2);
nW = size(W,2);
M = [];
q = lag(y,1);
rob = 1;
flag = 1;
sig = 0.05;
%Call the function
[ynl,ehat,alpha,beta,lambda,gamma,c,se,G,fX,pvalue] = mrstar(y,X,W,q,T,nX,nW,M,rob,flag,sig);


for i = R:(T-1)
roll_y = ynl(i-R+1:i,:);
roll_x = x(i-R+1:i,:);
      
l = mbic(roll_y,ones(R,1),roll_x, pmax);

rgr = ones(R-l+1,1);
for j = 1:l
    rgr = [rgr roll_x(l-j+1:end-j+1,:)];
end

[beta betaint e] = regress(roll_y(l:end,:),rgr);
sige = nw(e,qn);
        
oosgdp = [1 x(i+1,:) rgr(end,2:end-1)];
densforecast(1,i-R+1) = normcdf(y(i+1,1),oosgdp*beta,sige);
end
NS = 1:size(densforecast,2)-l;
densforecast = cumsum(cleanNaN(densforecast(:,l+1:end)),2)./NS;
%Figure 1
bin = 20; m = size(densforecast,2);
fn1 = figure;
hs = histc(densforecast,0:1/bin:1);
bar(0:1/bin:1,hs./m,'histc')
xlim([0 1])
ylim([0 1])
title('PIT for output growth - horizon(1)')
hold on

