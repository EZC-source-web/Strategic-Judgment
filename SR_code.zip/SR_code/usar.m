function [x,iseed] = usar(iseed, nd)
% This function simulate a linear AR(2) for the implementation of the BBQ 
%
randn('state',iseed);

xx=zeros(nd,1);
e = randn(nd,1);
u = e*.096;
i = 5;
xx(1) = 0.7477;
xx(2) = 0.7477;
xx(3) =0.7477;
xx(4) = 0.7477;
while i <= nd;
    xx(i) = .7477 + 7477*xx(i-1) -.2795*xx(i-2) + 0.2588*xx(i-3) + .3369*xx(i-4) +  u(i);
    i = 1+i;
end
x=xx;

end


