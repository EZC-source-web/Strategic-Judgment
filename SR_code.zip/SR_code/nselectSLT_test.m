function [hat_z, h0, z_nl, RES0, SSR0, sigma20, RES1, SSR1, sigma21, S1, CDF, pval_S1]...
    = nselectSLT_test(y_gstar, phi0, phi, theta0, theta, gamma1, gamma2, T, s, eta, sr, c)
%This funtion compute the SLT-type test for symmetry
%
%Step 0: Define the covariate matrix under the NULL HYPOTHESIS OF LINEARITY
hat_z = -[ones(size(y_gstar,1),1),lag(y_gstar,1),lag(y_gstar,2)];
beta10 = phi0 - 0.25*c*theta0;
e = [1, 0]';
Beta1 = phi - 0.25*c*theta + 0.25*theta0*e;
beta_tilde = [beta10, Beta1']';
z_lin = hat_z*beta_tilde; 
%sr = 2*(normpdf(eta',0,1) - norm(normpdf(eta',0,1)));
%Step 0-bis: define the matrix of augmented auxiliary model in case of
%asymmetry
h0 = [hat_z(:,2:end).*repmat(s,1,2).*repmat(sr,size(s,1),2), hat_z(:,2:end).*repmat(s.^2,1,2).*repmat(sr,size(s,1),2), hat_z(:,2:end).*repmat(s.^3,1,2).*repmat(sr,size(s,1),2)];

%Step 0-ter: Define the covariate matrix under the ALTERNATIVE HYPOTHESIS OF
%ASYMMETRY
z_nl = [z_lin, h0];

%Step 1: regress y on the covariate matrix under the null hp (THAT IS, 
%ESTIMATE A LINEAR MODEL given that the series is nonlinar) and compute the
%SSR0
results0=ols(y_gstar, z_lin);
RES0=[results0(1:end).resid];
SSR0=sum(RES0.^2);
sigma20 = (1/T)*SSR0;
    
%Step 2: Regress y on the COVARIANCE MATRIX UNDER
%ALTERNATIVE (that is estimate the true nonlinear model) and compute the
%SSR1
results1 = ols(RES0, z_nl);
RES1 = [results1(1:end).resid];
SSR1 = sum(RES1.^2);
sigma21 = (1/T)*SSR1;

%Step 3: built the test statistics LM2 (see T2010) using (F-version) and 
%the CDF and the p-value  for each draws
Gamma = [gamma1, gamma2, size(c,2)];
n = length(Gamma);
p = length(theta);
%S1 = (SSR0-SSR1)/sigma21;
S1 = ((SSR0-SSR1)/(2*p+n))/(SSR1/(T-2*p-n));
%CDF = cdf('chi2', S1, n);
CDF = cdf('f', S1, 2*p+n, T-2*p-n);
pval_S1 = 1-CDF;
end