function [qsr,wps,wps1,wps2,wps3,wps4,wps5,pseudosph,wpsph,wpsph1,wpsph2,wpsph3,wpsph4,wpsph5,logS,IntS,TsallisS,ES,GES,PSpectrum,crps,quant,CLS,CSL,HS,LCS]=scorings(fore,h,yhat,thresh,a,aleph,k,d,beta,gamma,c,flag)
% This function compute the scoring function 
%
% Step 1: estimate the pdf/cdf (inverted cdf) 
[f,xi] = ksdensity(fore(h,:),'kernel','epanechnikov','function','cdf');
[f1,xi1] = ksdensity(fore(h,:),'kernel','epanechnikov','function','pdf');
[f2,xi2] = ksdensity(fore(h,:),'kernel','epanechnikov','function','icdf');
[f3,xi3] = ksdensity(yhat,'kernel','epanechnikov','function','pdf');
[f4,xi4] = ksdensity(yhat,'kernel','epanechnikov','function','cdf');
pdf = f1; cdf = f;
cdf1 = f(:,50);  % fix cdf at the ?-th obs (normally the mean)
pdf1 = f1(:,50); % Some change in names...
cdf2 = quantile(f2,a); % "               "
pdf2 = f3; pdf21=pdf2(:,50);
cdf3 = f4;
[dpdf]=gradient(log(pdf)); [dpdf1]=gradient(log(pdf1));  [d2pdf]=gradient(gradient(log(pdf1)));
u = aleph/2; l= 1-aleph/2;
% Step 2a: defines the indicators and preallocate the weights vectors
I= length(yhat); J=length(cdf); 
w1=zeros(I,1); w2=zeros(I-2,1); w3=zeros(I,1); w4=zeros(J,1);
mu = mean(yhat);

% Step 2b: Defines the weights following the discretization in GR, formulas 16 - 17
u0 = 1;
u1 = pdf; 
u2 = 1-pdf1./pdf1(:,1);
u3 = cdf1;
u4 = 1-cdf1;
v0 = 1;
v1 = aleph.*(1-aleph);
v2 = (2.*aleph - 1).^2;
v3 = aleph.^2;
v4 = (1-aleph).^2;
for i=1:I-2
    w1(i) = (min(yhat)+i*range(yhat)/I)*u4; 
    w2(i) = (i/I)^2*v1;
end
for j = 1:J-2
w3(j) = u1(j);
w4(j) = 1/(exp(gamma(1)*(cdf(j)-c(1))));%+ 1/(exp(gamma(2)*(cdf(j)-c(2))));
%w5(j) = indicat(yhat(j),thresh);
end
   
% Step 2c: Define the Score functions
quadratic = 2*pdf1 - norm(pdf1)^2;                                                             %Quadratic Score
wpower = ((pdf21/pdf1)^(aleph-1) - 1)/(aleph-1) - (sum(pdf2/pdf1)^(aleph-1)-1)./aleph;         %Weighted Power Score (General)
wp1 = -.5*(1+(pdf21/pdf1)) + sum(pdf2/pdf1);                                                   %Weighted Power Score (Beta=1)
wp2 = 1 - (pdf21/pdf1) + sum(pdf2/pdf1);                                                       %Weighted Power Score (Beta=0)
wp3 = 2*(2 - (pdf21/pdf1) - sum(pdf2/pdf1));                                                   %Weighted Power Score (Beta=1/2)
wp4 = log(pdf21/pdf1);                                                                         %Weighted Power Score (Beta=1)
wp5 = (pdf21/pdf1 - 1) - .5*(sum(pdf2/pdf1));                                                  %Weighted Power Score (Beta=2)
pspherical = (pdf1^(aleph-1))/(norm(pdf1)^aleph);                                              %Pseudo-spherical Score 
wpspherical = 1/(aleph-1)*((((pdf21/pdf1).^(aleph-1))./(norm((pdf2/pdf1),aleph))).^aleph-1);   %Pseudo-spherical Score
wpspherical1 = .5*(1-(pdf21/pdf1)/sum(pdf2/pdf1)^2);                                           %Pseudo-spherical Score (Beta =-1)
wpspherical2 = 1 - (pdf21/pdf1).*exp(-sum(pdf2/pdf1));                                         %Pseudo-spherical Score (Beta =0)
wpspherical3 = 2*(1-sqrt(pdf21/pdf1)*sum(pdf2/pdf1));                                          %Pseudo-spherical Score (Beta =1/2)
wpspherical4 = log(pdf21/pdf1);                                                                %Pseudo-spherical Score (Beta =1)
wpspherical5 = ((pdf21/pdf1)/sqrt(sum(pdf2/pdf1)))-1;                                          %Pseudo-spherical Score (Beta =2)
logs = -(1/I)*sum(log(pdf1));                                                                  %Logarithmic Score
int = (u-l) + (2/aleph)*indicat(yhat,l) + (2/aleph)*(1-indicat(yhat,l));                       %Interval Score
tsallis = k/(d-1) + sum(pdf1*(1-pdf1)^(d-1));                                                  %Tsallis Score 
es = .5*norm((pdf - cdf))^beta - norm((mu - yhat))^beta;                                       %Energy score (with beta in (0,2))
ges = .5*norm((pdf - cdf),aleph)^beta - norm((mu - yhat),aleph)^beta;                          %Generalized Energy Score
pspectrum = - norm((pdf) - (exp(i*(pdf*toeplitz(pdf)*normpdf(length(pdf),0,1)))));             %Pseudo-Spectrum Score
ps = (cdf1-indicat(yhat,thresh)).^2;                                                           %(Weighted)CRPS
qs = 2*(indicat(cdf2,a)-a)*(cdf2 - yhat);                                                      %(Weigthed) Quantile Score
cls = (1/I*std(yhat))*sum(w3'.*(log(pdf21) - trapz(w3.*log(pdf21))));                          %Conditional Likelihood Score    
csl = (1/I*std(yhat))*sum(log(pdf*w4) + (log(1-((1/I)*trapz(pdf*(1-w4))))));                   %Censored Likelihood Score 
hs = (1/I*std(yhat))*sum((log(pdf)-(dpdf)).^2 + 2*(d2pdf));                                    %Hyvaarinen Score
lcs = -(log(cosh(dpdf1))-log(cosh(pdf1))) + (dpdf1./pdf1).*tanh(dpdf1./pdf1)...                %Log-Cosh Score
    + (d2pdf./pdf1 - (dpdf1./pdf1).^2).*tanh(tanh(dpdf1./pdf1));

% Step 3: Activate the indicator for Scoring the estimated model (discretized!)
if flag == 1
    qsr = quadratic; 
    wps = wpower;
    wps1 = wp1;
    wps2 = wp2;
    wps3 = wp3;
    wps4 = wp4;
    wps5 = wp5;
    pseudosph = pspherical;
    wpsph = wpspherical;
    wpsph1 = wpspherical1;
    wpsph2 = wpspherical2;
    wpsph3 = wpspherical3;
    wpsph4 = wpspherical4;
    wpsph5 = wpspherical5;
    logS = logs;
    IntS = int;
    TsallisS = tsallis;
    ES = es;
    GES = ges;
    PSpectrum = pspectrum;
    crps = (range(yhat)/(length(yhat)-1))*sum(w1*ps);
    quant = (1/(length(yhat)-1))*sum(w2.*qs(3:end)) ;
    CLS = cls;
    CSL = csl;
    HS = hs;
    LCS = lcs;
else
    qsr = 0;
    wps = 0;
    wps1 = 0;
    wps2 = 0;
    wps3 = 0;
    wps4 = 0;
    wps5 = 0;
    pseudosph = 0;
    wpsph = 0;
    wpsph1 = 0;
    wpsph2 = 0;
    wpsph3 = 0;
    wpsph4 = 0;
    wpsph5 = 0;
    logS = 0;
    IntS = 0;
    TsallisS = 0;
    ES = 0;
    GES = 0;
    PSpectrum = 0;
    crps = 0;  
    quant = 0;
    CLS = 0;
    CSL = 0;
    HS = 0;
    LCS = 0;
end
end