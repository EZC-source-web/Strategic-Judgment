function [gamma1,gamma2,c]=getpar_GSTAR(PSI) 

n     = size(PSI,1);
gamma1 = PSI(1:n/2);
gamma2 = PSI(1:n/2);
c     = PSI(n/2+1:n);