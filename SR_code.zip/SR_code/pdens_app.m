% This file replicates the empirical application of Locality test for real
% data
clear
clc

%% STEP 0: IMPORT AND TRANSFORM DATA 

% Import data
%importfile('/Users/emiliozanettichini/Desktop/WP/GSTR/Data/mUSIIP.xls');
%importfile('/Users/emiliozanettichini/Desktop/WP/GSTR/Data/mUSUN.xls');
%importfile('/Users/emiliozanettichini/Desktop/WP/GSTR/Data/LTIR.xls');
importfile('/Users/emiliozanettichini/Desktop/WP/GSTR/Data/NCPIm80.xls');
% DATA MANIPULATION FOR CO2
% 
% Select data
%y = 100*(log(mIIP) - lag(log(mIIP),12))/12; y=y(13:end);                 % US IIP in monthly growth rate
%y = 100*(log(mUN) - lag(log(mUN),12))/12; y=y(13:end);                   % US UNEMPLOYEMNT RATE in levels
%y = LTIRIT - LTIRDE;                                                     % Italian SPREAD
Y = [JAN FEB MAR APR MAY JUN JUL AUG SEPT OCT NOV DEC]; 
y = zeros(408,1);


y=[vec(Y(1,:)); vec(Y(2,:)); vec(Y(3,:)); vec(Y(4,:)); vec(Y(5,:)); vec(Y(6,:)); vec(Y(7,:)); vec(Y(8,:)); vec(Y(9,:)); vec(Y(10,:));... 
vec(Y(11,:)); vec(Y(12,:)); vec(Y(13,:)); vec(Y(14,:)); vec(Y(15,:)); vec(Y(16,:)); vec(Y(17,:)); vec(Y(18,:)); vec(Y(19,:)); vec(Y(20,:));...
vec(Y(21,:)); vec(Y(22,:)); vec(Y(23,:)); vec(Y(24,:)); vec(Y(25,:)); vec(Y(26,:)); vec(Y(27,:)); vec(Y(28,:)); vec(Y(29,:)); vec(Y(30,:));...
vec(Y(31,:)); vec(Y(32,:)); vec(Y(33,:)); vec(Y(34,:))];
y= 100*(log(y)-log(lag(y,1))); y=y(61:end);
T=length(y);
s=lag(y,1);
c=mean(y);

%Select the AR order via BIC
O = ones(length(y),1);
p = mbic(y, O, lag(y,1), 24);

% Call the function for GSTAR model
X = [O, lag(y,1)  lag(y,2)  lag(y,3)  lag(y,4) ]; 
W = [];         % Matrix of exogenous covariates
q = lag(y,1);   % 2 for IP, 1 for UN 
T = length(y);
nX = size(X,2); % # of covariates
nW = 0;         % # of Exogenous variables
M = [];         % Max # of Regimes (if empty the function compute it automatically)
rob = 1;        % HAC-robust test ?
flag = 1;       % the q is part of the covariates ?
sig = 0.05;      % nominal size (0.01 for IP and UN, 0.5for SPR, 0.1 for EI)
m=1; 
%initial values
gamma_0=0;
gamma1_0=0;
gamma2_0=0;
%Estimate the AR(1)

y_ar=ols(y, [O lag(y,1), lag(y,2), lag(y,3), lag(y,4)]);
yhat_ar = y_ar.yhat
lambda_ar = y_ar.beta;
% ESTIMATE THE GSTAR
% Call the function for GSTAR model
[alpha_gstar,beta_gstar,lambda_gstar,gamma1,gamma2,c_gstar,fX_gstar,yhat_gstar,ehat_gstar,G_gstar,sigma_gstar,se_gstar]=parestGSTARlm(y,X,W,q,T,nX,nW,m,gamma1_0,gamma2_0,c(1));

% Call other function for the Score Matrix and further results
[eta, h_stuk, MU_stuk, G_stuk] = G_stukel(s-c_gstar, gamma1, gamma2);
eta=yhat_gstar';
eta_t=[q-c_gstar];
[Ggamma1] = Ggamma1(gamma1, gamma2, h_stuk,  eta, eta_t, T);
[Ggamma2] = Ggamma2(gamma1, gamma2, h_stuk, eta, eta_t,T);
[Gc] = Gc(gamma1, gamma2, h_stuk, eta, eta_t,T);

thresh = mean(y); 
gamma=1;          %threshold parameter for weigths of CLS/CSL
%y=yhat_gstar;
flag=1; %Set flag=1 if you want activate the scoring rule, 0 otherwise
a=0.1;     % quantile
aleph=0.5; % alpha parameter for Weighted Pseudospherical and Power Scores
d=2;
beta=0.3;  % Beta parameter for Energy and Generalized Energy Scores
n=7; 

H=60; % number of forecast periods
S=300;

hist=yhat_gstar;

% Copute the scoring rules
a=0.1;
aleph=0.5;
k=1;
d=2;
beta=0.3;
[fore, qsr,wps,wps1,wps2,wps3,wps4,wps5,pseudosph,wpsph,wpsph1,wpsph2,wpsph3,wpsph4,wpsph5,logS,IntS,TsallisS,ES,GES,PSpectrum,crps,quant,CLS,CSL,HS,LCS]=scores(yhat_gstar,thresh,a,aleph,k,d,beta,gamma,c_gstar,flag,lambda_gstar, H,S,T,123456);
[fore_ar, qsr_ar,wps_ar,wps1_ar,wps2_ar,wps3_ar,wps4_ar,wps5_ar,pseudosph_ar,wpsph_ar,wpsph1_ar,wpsph2_ar,wpsph3_ar,wpsph4_ar,wpsph5_ar,logS_ar,IntS_ar,TsallisS_ar,ES_ar,GES_ar,PSpectrum_ar,crps_ar,quant_ar,CLS_ar,CSL_ar,HS_ar,LCS_ar]=scores(yhat_ar,thresh,a,aleph,k,d,beta,gamma,c_gstar,flag,lambda_ar, H,S,T,123456);
SR = [qsr,wps,wps1,wps2,wps3,wps4,wps5,pseudosph,wpsph,wpsph1,wpsph2,wpsph3,wpsph4,wpsph5,logS,IntS,TsallisS,ES,GES,PSpectrum,crps,quant,CLS,CSL,HS,LCS];
SR_ar = [qsr_ar,wps_ar,wps1_ar,wps2_ar,wps3_ar,wps4_ar,wps5_ar,pseudosph_ar,wpsph_ar,wpsph1_ar,wpsph2_ar,wpsph3_ar,wpsph4_ar, wpsph5_ar, logS_ar,IntS_ar,TsallisS_ar,ES_ar,GES_ar,PSpectrum_ar,crps_ar,quant_ar,CLS_ar,CSL_ar,HS_ar,LCS_ar];

Delta = SR - SR_ar;
sigma = 1/(T+H-1)*sum(kron(mean(fore,2), Delta));
t_val = sqrt(n)*(Delta./sigma);
CDF = cdf('t', t_val, T-H-1);
Pval = 1-CDF;

%logS = logScore(yhat_gstar,T); 
Z=[ones(1,length(X)); X'];

% Locality test
[LM1, LM2, LM3, pval_LM1, pval_LM2, pval_LM3] = ScoreSelection_test(yhat_gstar, s,logS, Z, T, fX_gstar, Ggamma1, Ggamma2, Gc);
b = bootstrp(1000,@mean,yhat_gstar);
[pdf_boot,xi] = ksdensity(b);
plot(xi,pdf_boot);

% Call fan chart function
%FanChart(fore,hist,'2011',1);

%%%% PLOT THE RESULTS %%%%%%%%
disp('****************************************************************')
disp('                         LOCALITY TEST                        ')
disp('**************************************************************')
disp('-------------------------------------------------------------')
disp('               Statistic       ||            P-value         ')
disp('-------------------------------||----------------------------')
disp('      F1    |   F2    |   F3   ||   F1    |   F2   |    F3   ')
disp('    ------  | ------  | ------ || ------  | ------ |  ------ ')
disp( [LM1 LM2 LM3 pval_LM1 pval_LM2 pval_LM3])
disp('-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------')
disp('----------------------------------------')
disp('SCORING RULES for the ESTIMATED MODEL')
disp('           GSTAR                  |      AR   |     sigma_n    |      t_n      |      Pval     ')
disp(['QSR: ', num2str(qsr), '                  |     ', num2str(qsr_ar) '   |     ', num2str(sigma(1)), '    |     ', num2str(t_val(1)), '     |     ',  num2str(Pval(1))])
disp('        ')
disp(['WPowerS: ', num2str(wps), '              |     ', num2str(wps_ar) '   |     ', num2str(sigma(2)), '    |     ', num2str(t_val(2)), '     |     ',  num2str(Pval(2))])
disp('        ')
disp(['WPowerS (aleph=-1): ', num2str(wps1), '  |     ', num2str(wps_ar) '   |     ', num2str(sigma(3)), '    |     ', num2str(t_val(3)), '     |     ',  num2str(Pval(3))])
disp('        ')
disp(['WPowerS (aleph=0): ', num2str(wps2), '   |     ',num2str(wps2_ar) '   |     ', num2str(sigma(4)), '    |     ', num2str(t_val(4)), '     |     ',  num2str(Pval(4)) ])
disp('        ') 
disp(['WPowerS (aleph=1/2): ', num2str(wps3),'  |     ',num2str(wps3_ar) '   |     ', num2str(sigma(5)), '    |     ', num2str(t_val(5)), '     |     ',  num2str(Pval(5))])
disp('        ')
disp(['WPowerS (aleph=1): ', num2str(wps4),'    |     ',num2str(wps4_ar) '   |     ', num2str(sigma(6)), '    |     ', num2str(t_val(6)), '     |     ',  num2str(Pval(6))])
disp('        ')
disp(['WPowerS (aleph=2): ', num2str(wps5),'    |     ',num2str(wps5_ar) '   |     ', num2str(sigma(7)), '    |     ', num2str(t_val(7)), '     |     ',  num2str(Pval(7))])
disp('        ')
disp(['PseudoSph: ', num2str(pseudosph),'       |     ',num2str(pseudosph_ar) '   |     ', num2str(sigma(8)), '     |     ', num2str(t_val(8)), '     |     ',  num2str(Pval(8))])
disp('        ')
disp(['WPseudoSph: ', num2str(wpsph),'          |     ',num2str(wpsph_ar) '    |     ', num2str(sigma(9)), '      |     ', num2str(t_val(9)), '   |     ',  num2str(Pval(9))])
disp('        ')
disp(['WPseudoSph (aleph=-1): ', num2str(wpsph1),'   |     ',num2str(wpsph1_ar) '   |     ', num2str(sigma(10)), '     |     ', num2str(t_val(10)), '    |     ',  num2str(Pval(10))])
disp('        ')
disp(['WPseudoSph (aleph=0): ', num2str(wpsph2),'    |     ',num2str(wpsph2_ar) '   |     ', num2str(sigma(11)), '     |     ', num2str(t_val(11)), '   |     ',  num2str(Pval(11))])
disp('        ')
disp(['WPseudoSph (aleph=1/2): ', num2str(wpsph3),'  |     ',num2str(wpsph2_ar) '   |     ', num2str(sigma(12)), '     |     ', num2str(t_val(12)), '     |     ',  num2str(Pval(12))])
disp('        ')
disp(['WPseudoSph (aleph=1): ', num2str(wpsph4),'    |     ',num2str(wpsph4_ar) '   |     ', num2str(sigma(13)), '     |     ', num2str(t_val(13)), '     |     ',  num2str(Pval(13))])
disp('        ')
disp(['WPseudoSph (aleph=2): ', num2str(wpsph5),'    |     ',num2str(wpsph5_ar) '   |     ', num2str(sigma(14)), '     |     ', num2str(t_val(14)), '     |     ',  num2str(Pval(14))])
disp('        ')
disp(['LogS: ', num2str(logS),'    |   ',num2str(logS_ar) '   |   ', num2str(sigma(15)), '   |     ', num2str(t_val(15)), '    |     ',  num2str(Pval(15))])
disp('        ')
disp(['IntS: ', num2str(IntS),'    |   ',num2str(IntS_ar) '   |   ', num2str(sigma(16)), '   |     ', num2str(t_val(16)), '    |     ',  num2str(Pval(16))])
disp('        ')
disp(['TsallisS: ', num2str(TsallisS),'   |     ',num2str(TsallisS_ar) '       |     ', num2str(sigma(17)), '     |     ', num2str(t_val(17)), '     |     ',  num2str(Pval(17))])
disp('        ')
disp(['ES: ', num2str(ES),'   |     ',num2str(ES_ar) '     |     ', num2str(sigma(18)), '   |     ', num2str(t_val(18)), '     |     ',  num2str(Pval(18))])
disp('        ')
disp(['GES: ', num2str(GES),'  |     ',num2str(GES_ar) '   |     ', num2str(sigma(19)), '   |     ', num2str(t_val(19)), '     |     ',  num2str(Pval(19))])
disp('        ')
disp(['PseudoSpectrum: ', num2str(PSpectrum),'   |     ',num2str(PSpectrum_ar) '    |     ', num2str(sigma(20)), '      |     ', num2str(t_val(20)), '     |     ',  num2str(Pval(20))])
disp('        ')
disp(['CRPS: ', num2str(crps),'    |     ',num2str(crps_ar) '    |     ', num2str(sigma(21)), '    |     ', num2str(t_val(21)), '       |     ',  num2str(Pval(21))])
disp('        ')
disp(['QuantS: ', num2str(quant),'  |     ',num2str(quant_ar) '   |     ', num2str(sigma(22)), '    |     ', num2str(t_val(22)), '      |     ',  num2str(Pval(22))])
disp('        ')
disp(['CLS: ', num2str(CLS),'       |     ',num2str(CLS_ar) '     |     ', num2str(sigma(23)), '    |     ', num2str(t_val(23)), '      |     ',  num2str(Pval(23))])
disp('        ')
disp(['CSL: ', num2str(CSL),'     |     ',num2str(CSL_ar) '     |     ', num2str(sigma(24)), '    |     ', num2str(t_val(24)), '      |     ',  num2str(Pval(24))])
disp('        ')
disp(['HS: ', num2str(HS),'      |     ',num2str(HS_ar) '     |     ', num2str(sigma(25)), '    |     ', num2str(t_val(25)), '       |     ',  num2str(Pval(25))])
disp('        ')
disp(['LCS: ', num2str(LCS),'     |     ',num2str(LCS_ar) '   |     ', num2str(sigma(26)), '    |     ', num2str(t_val(26)), '       |     ',  num2str(Pval(26))])
disp('        ')
disp('--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------')