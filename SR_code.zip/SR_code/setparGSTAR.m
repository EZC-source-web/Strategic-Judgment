function PSI = setparGSTAR(gamma1,gamma2,c)
% Vectorize the three parameters of G function of a GLSTAR
PSI = [gamma1; gamma2; c];
end