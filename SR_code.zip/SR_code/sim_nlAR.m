function [y_nl1, u_nl] = sim_nlAR(theta0, theta, G, T, sigerr)

%Preallocate
y_nl1 = zeros(T,1);

%Definitions
eps = sqrt(sigerr)*randn(T,1);

%Simulate a Nonlinear (GSTAR) process
for i= 3 : T-1
    y_nl1(i) = theta0 + [G(i-1), G(i-2)]*theta + eps(i);
    u_nl = y_nl1  - theta0 - [G(i-1), G(i-2)]*theta ;
end
y_nl1=y_nl1(3:end,:); 
end