clc;
clear
%importfile('/Users/emiliozanettichini/Desktop/WP/SR/Code/Data_q.xls');
iseed=123456;

%REAL DATA - has to be in LN form unless log command is not commented out
%x = IIP;
%x=log(x);
%x = 100*(diff(log(x),1)); % Growth rates
%T = length(x);

%% Simulate the Marginal Density from Estimated Model

% Linear part
phi0 = 0.0;
phi1 = 0.4;
phi2 = -0.25;
% NON-Linear part
theta0 = 0.01;
theta1 = -0.9;
theta2 = 0.795;
% Slope parameters
gamma1 = -200;
gamma2 = 100;
% Other parameters
T = 300;
nsim = 10;
alpha01 = 0.01; alpha05 = 0.05; alpha10 = 0.1;
sigerr = 1;
d=100;     % Discard the first 1,...d simulations
B = 10000; % number of re-sampling of the estimated statistic
%
%% STEP 1: INITIALIZATION
%Generate a linear AR in order to have w which is required for G and the
%Hessian
[y, eps, phi, w, u_l] = sim_nAR(phi0, phi1, phi2, T , sigerr);
%Generate G
[theta, eta, s, c, eta_t, h, mu, G] = sim_G_glstar1(phi0, phi1, phi2, theta0, theta1, theta2, gamma1, gamma2, y, T);
%
%Build up the elements of the Score and Hessian (for whom I need only the
%parameters gamma1 gamma2, T, eta and eta_t which in turns are function
%of the Linear AR model previously defined.
[Ggamma1] = Ggamma1(gamma1, gamma2, h, eta, eta_t, T);
[Ggamma2] = Ggamma2(gamma1, gamma2, h, eta, eta_t, T);
[Gc] = Gc(gamma1, gamma2, h, eta, eta_t, T);

%%  STEP 2: SIMULATE a LINEAR AR(2) process   
% 
%Step 2.a: Generate a linear AR in order to have w which is required for G 
%and the Hessian 
[y, eps, phi, w, u_l] = sim_nAR(phi0, phi1, phi2, T , sigerr);
%
%Step 2.b: Generate the nonlinear function G
[theta, eta, s, c, eta_t, h, mu, G]=sim_G_glstar1(phi0, phi1, phi2, theta0, theta1, theta2, gamma1, gamma2, y, T);
%
%Step 2.c: Generate the NON-LINEAR part of the process in order to have w 
%which is required for G and the Hessian
[y_nl, u_nl] = sim_nlAR(theta0, theta, G, T, sigerr);

%Step 2.d: Define the GLSTAR1 as the sum of the Linear AR + Nonlinear AR 
% previously defined
[y_gstar, u, sigma2_hat, sigma_hat] = nsim_GLSTAR1(T, y, y_nl, u_nl);
bar_z = [lag(y,1), lag(y,2)]';
Z = [ones(1,length(bar_z))', bar_z']';
%
% STEP 2.e: DEFINE THE  GSTAR as the sum of the Linear AR + Nonlinear AR 
%previously defined
[y_gstar, u, sigma2_hat, sigma_hat] = nsim_GLSTAR1(T, y, y_nl, u_nl);

% Call the function for GSTAR model
W = [];         % Matrix of exogenous covariates
q = lag(y,1);   % 2 for IP, 1 for UN 
T = length(y);
nX = size(Z',2); % # of covariates
nW = 0;         % # of Exogenous variables
M = [];         % Max # of Regimes (if empty the function compute it automatically)
rob = 1;        % HAC-robust test ?
flag = 1;       % the q is part of the covariates ?
sig = 0.1;      % nominal size (0.01 for IP and UN, 0.5for SPR, 0.1 for EI)
m=1; 
%initial values
gamma_0=0;
gamma1_0=0;
gamma2_0=0;

[alpha_gstar,beta_gstar,lambda_gstar,gamma1,gamma2,c_gstar,fX_gstar,yhat_gstar,ehat_gstar,G_gstar,sigma_gstar,se_gstar]=parestGSTARlm(y_gstar,Z',W,q,T,nX,nW,m,gamma1_0,gamma2_0,c(1));

%vY = vec(Y);
b = bootstrp(B,@mean,yhat_gstar);
[pdf_boot,xi] = ksdensity(b);
plot(xi,pdf_boot);

% Generate artifical history and forecasts
H=60; % number of forecast periods
fore=randn(H,500);
for h=1:H
   fore(h,:)=(fore(h,:).*h)./100; 
end
hist=yhat_gstar;

% Call fan chart function
FanChart(fore,hist,'Dec2012',6);

