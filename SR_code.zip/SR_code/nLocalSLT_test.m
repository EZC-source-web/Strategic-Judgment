function [hat_z, h01, h02, h03, z_nl, S_LM1, S_LM2, S_LM3, pval_LM1, pval_LM2, pval_LM3]...
    = nLocalSLT_test(y_gstar, phi0, phi, theta0, theta, gamma1, gamma2, T, s, k, sr, c)
%This funtion compute the SLT-type test for symmetry
%
%Step 0: Define the covariate matrix under the NULL HYPOTHESIS OF LINEARITY
hat_z = -[ones(size(y_gstar,1),1),lag(y_gstar,1),lag(y_gstar,2)];
beta10 = phi0 - 0.25*c*theta0;
e = [1, 0]';
Beta1 = phi - 0.25*c*theta + 0.25*theta0*e;
beta_tilde = [beta10, Beta1']';
z_lin = hat_z*beta_tilde; 
%sr = 2*(normpdf(eta',0,1) - norm(normpdf(eta',0,1)));
%Step 0-bis: define the matrix of augmented auxiliary model in case of
%asymmetry  
h01 = [hat_z(:,2:end).*repmat(s,1,2).*repmat(k*sr,size(s,1),2)];
h02 = [hat_z(:,2:end).*repmat(s,1,2).*repmat(k*sr,size(s,1),2), hat_z(:,2:end).*repmat(s.^2,1,2).*repmat(k*sr,size(s,1),2)];
h03 = [hat_z(:,2:end).*repmat(s,1,2).*repmat(k*sr,size(s,1),2), hat_z(:,2:end).*repmat(s.^2,1,2).*repmat(k*sr,size(s,1),2), hat_z(:,2:end).*repmat(s.^3,1,2).*repmat(k*sr,size(s,1),2)];
%Step 0-ter: Define the covariate matrix under the ALTERNATIVE HYPOTHESIS OF
%ASYMMETRY
z_nl01 = [z_lin  h01];
z_nl02 = [z_lin  h02];
z_nl = [z_lin h03];
%z_nl03 = [z_lin, h03];
%Step 1: regress y on the covariate matrix under the null hp (THAT IS, 
%ESTIMATE A LINEAR MODEL given that the series is nonlinar) and compute the
%SSR0
results01=ols(y_gstar, z_lin);   results02=ols(y_gstar, z_nl01); results03=ols(y_gstar, z_nl02);
RES01=[results01(1:end).resid];  RES02=[results02(1:end).resid]; RES03=[results03(1:end).resid];
SSR01=sum(RES01.^2);             SSR02=sum(RES02.^2);            SSR03=sum(RES03.^2);
sigma201 = (1/T)*SSR01;
    
%Step 2: Regress y on the COVARIANCE MATRIX UNDER
%ALTERNATIVE (that is estimate the true nonlinear model) and compute the
%SSR1
results1 = ols(y_gstar, z_nl);
RES1 = [results1(1:end).resid];
SSR1 = sum(RES1.^2);
sigma21 = (1/T)*SSR1;

%Step 3: built the test statistics LM2 (see T2010) using (F-version) and 
%the CDF and the p-value  for each draws
Gamma = [gamma1, gamma2, size(c,2)];
n = length(Gamma);
p = length(theta);
%S1 = (SSR0-SSR1)/sigma21;
S_LM1 = ((SSR01-SSR1)/(3*p+n))/(SSR1/(T-3*p-n)); S_LM2 = ((SSR02-SSR1)/(2*p+n))/(SSR1/(T-2*p-n)); S_LM3 = ((SSR03-SSR1)/(p+n))/(SSR1/(T-p-n));
%CDF = cdf('chi2', S1, n);
CDF_LM1 = cdf('f', S_LM1, 3*p+n, T-3*p-n); CDF_LM2 = cdf('f', S_LM2, 2*p+n, T-2*p-n); CDF_LM3 = cdf('f', S_LM3, p+n, T-p-n);
pval_LM1 = 1-CDF_LM1; pval_LM2 = 1-CDF_LM2; pval_LM3 = 1-CDF_LM3;
end