%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Codice MATLAB per riprodurre le Figure 4 e 5 del paragrafo 2.2 del paper
% con la logica Step 2 / Step 4 e la costruzione dei PIT (Probability
% Integral Transform).
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear; clc; close all;

%% Parametri comuni
N   = 1000;    % Numero di percorsi simulati
T   = 265;     % Dimensione del campione in-sample
pi_ = 0.01;    % Bias "sospettato" dal Forecast User (FU)
psi = 0.01;    % Bias effettivo che il FP aggiunge nella seconda previsione
              % (dal punto di vista di FU, lo shift totale e' pi_ + psi = 0.10)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%               FIGURA 4: DGP i.i.d. con media sconosciuta
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Vettori per memorizzare i PIT (Step 2 e Step 4)
PIT_iid_step2 = zeros(N,1);
PIT_iid_step4 = zeros(N,1);

% Fissiamo un seed per riproducibilita'
rng(123);

for i = 1:N
    
    % 1) Generiamo la media vera mu ~ N(0,1)
    mu = randn;
    
    % 2) Generiamo la serie y di lunghezza T+2: y = mu + N(0,1)
    y = mu + randn(T+2,1);
    
    % 3) Stima in-sample: forecast ottimale come media dei primi T dati
    yhat = mean(y(1:T));
    
    %% STEP 2 (pannello (a) di Figura 4)
    % Dal punto di vista di FU, c'e' un bias pi_
    forecast_eval_2 = yhat + pi_;
    
    % Calcolo del PIT (con varianza 1) per il dato T+1
    PIT_iid_step2(i) = normcdf(y(T+1) - forecast_eval_2, 0, 1);
    
    
    %% STEP 4 (pannello (b) di Figura 4)
    % Il FP aggiunge psi per la previsione su T+2
    % Dal punto di vista di FU, lo shift totale e' pi_ + psi
    forecast_eval_4 = yhat + (pi_ + psi);
    
    % Calcolo del PIT per il dato T+2
    PIT_iid_step4(i) = normcdf(y(T+2) - forecast_eval_4, 0, 1);
end

% ---- Grafico Figura 4 ----
figure('Name','Figura 4: i.i.d. con media sconosciuta','Position',[100 100 700 600]);

% (a) PIT Step 2
subplot(2,1,1)
histogram(PIT_iid_step2, 'Normalization','pdf', 'NumBins',5, 'FaceColor','b');
hold on;
x_vals = linspace(0,1,100);
plot(x_vals, ones(size(x_vals)), 'r--', 'LineWidth', 2); % Linea uniform(0,1)
title('(a) PIT al Step 2 (i.i.d. con media sconosciuta)');
xlabel('PIT'); ylabel('Densita''');
hold off;

% (b) PIT Step 4
subplot(2,1,2)
histogram(PIT_iid_step4, 'Normalization','pdf', 'NumBins',5, 'FaceColor','b');
hold on;
plot(x_vals, ones(size(x_vals)), 'r--', 'LineWidth', 2);
title('(b) PIT al Step 4 (i.i.d. con media sconosciuta)');
xlabel('PIT'); ylabel('Densita''');
hold off;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%               FIGURA 5: DGP LSTAR(2)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Parametri del modello LSTAR(2)
sigma2 = 0.5;
sigma  = sqrt(sigma2);

a1    = 0.9;
a2    = -0.795;
b0    = 0.02;
b1    = -0.4;
b2    = 0.25;
gamma = 5.0;

% Vettori per memorizzare i PIT (Step 2 e Step 4)
PIT_lstar_step2 = zeros(N,1);
PIT_lstar_step4 = zeros(N,1);

% Nuovo seed per la parte LSTAR
rng(999);

for i = 1:N
    
    % 1) Inizializziamo y(1)=0, y(2)=0
    y = zeros(T+2,1);
    y(1) = 0;
    y(2) = 0;
    
    % 2) Simuliamo i dati dal modello LSTAR(2) fino a T+2
    for t = 3:(T+2)
        if t <= T
            c = mean(y(1:t-1)); % stima c come media (fase in-sample)
        else
            c = mean(y(1:T));   % out-of-sample, semplifichiamo
        end
        
        % Funzione di transizione
        G = 1 / (1 + exp(-gamma*(y(t-1) - c)));
        
        % LSTAR(2)
        y(t) = a1*y(t-1) + a2*y(t-2) + ...
               (b0 + b1*y(t-1) + b2*(y(t-2))^2)*G + sigma*randn;
    end
    
    % 3) Forecast "vero" (senza bias) per T+1
    c_in = mean(y(1:T));
    G_in = 1 / (1 + exp(-gamma*(y(T) - c_in)));
    forecast_true_T1 = a1*y(T) + a2*y(T-1) + ...
                       (b0 + b1*y(T) + b2*(y(T-1))^2)*G_in;
    
    %% STEP 2 (pannello (a) di Figura 5)
    % FU sospetta pi_
    forecast_eval_2 = forecast_true_T1 + pi_;
    
    % Calcolo PIT per T+1 (varianza sigma^2)
    PIT_lstar_step2(i) = normcdf(y(T+1) - forecast_eval_2, 0, sigma);
    
    
    % 4) Forecast "vero" (senza bias) per T+2
    %    (ipotesi: stima c ancora su y(1:T), per semplicita')
    c_in2 = mean(y(1:T));
    G_in2 = 1 / (1 + exp(-gamma*(y(T) - c_in2)));
    forecast_true_T2 = a1*y(T) + a2*y(T-1) + ...
                       (b0 + b1*y(T) + b2*(y(T-1))^2)*G_in2;
    
    %% STEP 4 (pannello (b) di Figura 5)
    % Il FP aggiunge psi
    % Dal punto di vista di FU, c'e' di nuovo pi_, per uno shift totale pi_+psi
    forecast_eval_4 = forecast_true_T2 + (pi_ + psi);
    
    % Calcolo PIT per T+2
    PIT_lstar_step4(i) = normcdf(y(T+2) - forecast_eval_4, 0, sigma);
end

% ---- Grafico Figura 5 ----
figure('Name','Figura 5: LSTAR(2)','Position',[850 100 700 600]);

% (a) PIT Step 2
subplot(2,1,1)
histogram(PIT_lstar_step2, 'Normalization','pdf','NumBins',5, 'FaceColor','b');
hold on;
x_vals = linspace(0,1,100);
plot(x_vals, ones(size(x_vals)), 'r--','LineWidth',2);
title('(a) PIT al Step 2 (Modello LSTAR(2))');
xlabel('PIT'); ylabel('Densita''');
hold off;

% (b) PIT Step 4
subplot(2,1,2)
histogram(PIT_lstar_step4, 'Normalization','pdf','NumBins',5, 'FaceColor','b');
hold on;
plot(x_vals, ones(size(x_vals)), 'r--','LineWidth',2);
title('(b) PIT al Step 4 (Modello LSTAR(2))');
xlabel('PIT'); ylabel('Densita''');
hold off;

