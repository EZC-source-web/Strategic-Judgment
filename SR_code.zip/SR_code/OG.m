clc;
clear
importfile('/Users/emiliozanettichini/Desktop/SR_code/NOG.xls')

F = [L90 L70 L50 L30 OGp U90 U70 U50 U30];
mu = mean(F,1);
sigma = var(F);
T=length(F);
Pdens=zeros(T,1);
n = 6;

a=0.1;
aleph=0.5;
k=1;
d=2;
beta=0.3;
thresh = 7.5;
%Average the Fan Chart Upper and Lower percentiles 
for i=1:T
Pdens(i,:) = (1/size(F,2))*(sum(pdf('norm',F(i,:),mu,sigma),2));
end
y=Pdens;

%Start with Scoring Rules

%LSR = -(1/T)*sum(log(Pdens));
%qsr = (1/T)*sum(2*Pdens - sum((F-repmat(Pdens,1,size(F,2)).^2),2));
h=12;
H=1;
fore=y;
[qsr,wps,wps1,wps2,wps3,wps4,wps5,pseudosph,wpsph,wpsph1,wpsph2,wpsph3,wpsph4,wpsph5,logS,IntS,TsallisS,ES,GES,PSpectrum,crps,quant,CLS,CSL,HS,LCS]=scorings(y,h,y,2,a,aleph,k,d,beta,1,mean(y),1);
O = ones(length(y),1);
y_ar=ols(y, [O lag(y,1)]);
yhat_ar = y_ar.yhat;
lambda_ar = y_ar.beta;
[qsr_ar,wps_ar,wps1_ar,wps2_ar,wps3_ar,wps4_ar,wps5_ar,pseudosph_ar,wpsph_ar,wpsph1_ar,wpsph2_ar,wpsph3_ar,wpsph4_ar,wpsph5_ar,logS_ar,IntS_ar,TsallisS_ar,ES_ar,GES_ar,PSpectrum_ar,crps_ar,quant_ar,CLS_ar,CSL_ar,HS_ar,LCS_ar]=scorings(yhat_ar,T,yhat_ar,thresh,a,aleph,k,d,beta,1,mean(y),1);
SR = [qsr,wps,wps1,wps2,wps3,wps4,wps5,pseudosph,wpsph,wpsph1,wpsph2,wpsph3,wpsph4,wpsph5,logS,IntS,TsallisS,ES,GES,PSpectrum,crps,quant,CLS,CSL,HS,LCS];
SR_ar = [qsr_ar,wps_ar,wps1_ar,wps2_ar,wps3_ar,wps4_ar,wps5_ar,pseudosph_ar,wpsph_ar,wpsph1_ar,wpsph2_ar,wpsph3_ar,wpsph4_ar, wpsph5_ar, logS_ar,IntS_ar,TsallisS_ar,ES_ar,GES_ar,PSpectrum_ar,crps_ar,quant_ar,CLS_ar,CSL_ar,HS_ar,LCS_ar];


Delta = SR - SR_ar;
sigma = 1/(T+H-1)*sum(kron(mean(fore,2), Delta)).^2;
t_val = sqrt(n)*(Delta./sigma);
CDF = cdf('t', t_val, T+H-1);
Pval = 1-CDF;


disp('SCORING RULES for the ESTIMATED MODEL')
disp('           NB                 |      AR   |     sigma_n    |      t_n      |      Pval     ')
disp(['QSR: ', num2str(qsr), '                  |     ', num2str(qsr_ar) '   |     ', num2str(sigma(1)), '    |     ', num2str(t_val(1)), '     |     ',  num2str(Pval(1))])
disp('        ')
disp(['WPowerS: ', num2str(wps), '              |     ', num2str(wps_ar) '   |     ', num2str(sigma(2)), '    |     ', num2str(t_val(2)), '     |     ',  num2str(Pval(2))])
disp('        ')
disp(['WPowerS (aleph=-1): ', num2str(wps1), '  |     ', num2str(wps_ar) '   |     ', num2str(sigma(3)), '    |     ', num2str(t_val(3)), '     |     ',  num2str(Pval(3))])
disp('        ')
disp(['WPowerS (aleph=0): ', num2str(wps2), '   |     ',num2str(wps2_ar) '   |     ', num2str(sigma(4)), '    |     ', num2str(t_val(4)), '     |     ',  num2str(Pval(4)) ])
disp('        ') 
disp(['WPowerS (aleph=1/2): ', num2str(wps3),'  |     ',num2str(wps3_ar) '   |     ', num2str(sigma(5)), '    |     ', num2str(t_val(5)), '     |     ',  num2str(Pval(5))])
disp('        ')
disp(['WPowerS (aleph=1): ', num2str(wps4),'    |     ',num2str(wps4_ar) '   |     ', num2str(sigma(6)), '    |     ', num2str(t_val(6)), '     |     ',  num2str(Pval(6))])
disp('        ')
disp(['WPowerS (aleph=2): ', num2str(wps5),'    |     ',num2str(wps5_ar) '   |     ', num2str(sigma(7)), '    |     ', num2str(t_val(7)), '     |     ',  num2str(Pval(7))])
disp('        ')
disp(['PseudoSph: ', num2str(pseudosph),'       |     ',num2str(pseudosph_ar) '   |     ', num2str(sigma(8)), '     |     ', num2str(t_val(8)), '     |     ',  num2str(Pval(8))])
disp('        ')
disp(['WPseudoSph: ', num2str(wpsph),'          |     ',num2str(wpsph_ar) '    |     ', num2str(sigma(9)), '      |     ', num2str(t_val(9)), '   |     ',  num2str(Pval(9))])
disp('        ')
disp(['WPseudoSph (aleph=-1): ', num2str(wpsph1),'   |     ',num2str(wpsph1_ar) '   |     ', num2str(sigma(10)), '     |     ', num2str(t_val(10)), '    |     ',  num2str(Pval(10))])
disp('        ')
disp(['WPseudoSph (aleph=0): ', num2str(wpsph2),'    |     ',num2str(wpsph2_ar) '   |     ', num2str(sigma(11)), '     |     ', num2str(t_val(11)), '   |     ',  num2str(Pval(11))])
disp('        ')
disp(['WPseudoSph (aleph=1/2): ', num2str(wpsph3),'  |     ',num2str(wpsph2_ar) '   |     ', num2str(sigma(12)), '     |     ', num2str(t_val(12)), '     |     ',  num2str(Pval(12))])
disp('        ')
disp(['WPseudoSph (aleph=1): ', num2str(wpsph4),'    |     ',num2str(wpsph4_ar) '   |     ', num2str(sigma(13)), '     |     ', num2str(t_val(13)), '     |     ',  num2str(Pval(13))])
disp('        ')
disp(['WPseudoSph (aleph=2): ', num2str(wpsph5),'    |     ',num2str(wpsph5_ar) '   |     ', num2str(sigma(14)), '     |     ', num2str(t_val(14)), '     |     ',  num2str(Pval(14))])
disp('        ')
disp(['LogS: ', num2str(logS),'    |   ',num2str(logS_ar) '   |   ', num2str(sigma(15)), '   |     ', num2str(t_val(15)), '    |     ',  num2str(Pval(15))])
disp('        ')
disp(['IntS: ', num2str(IntS),'    |   ',num2str(IntS_ar) '   |   ', num2str(sigma(16)), '   |     ', num2str(t_val(16)), '    |     ',  num2str(Pval(16))])
disp('        ')
disp(['TsallisS: ', num2str(TsallisS),'   |     ',num2str(TsallisS_ar) '       |     ', num2str(sigma(17)), '     |     ', num2str(t_val(17)), '     |     ',  num2str(Pval(17))])
disp('        ')
disp(['ES: ', num2str(ES),'   |     ',num2str(ES_ar) '     |     ', num2str(sigma(18)), '   |     ', num2str(t_val(18)), '     |     ',  num2str(Pval(18))])
disp('        ')
disp(['GES: ', num2str(GES),'  |     ',num2str(GES_ar) '   |     ', num2str(sigma(19)), '   |     ', num2str(t_val(19)), '     |     ',  num2str(Pval(19))])
disp('        ')
disp(['PseudoSpectrum: ', num2str(PSpectrum),'   |     ',num2str(PSpectrum_ar) '    |     ', num2str(sigma(20)), '      |     ', num2str(t_val(20)), '     |     ',  num2str(Pval(20))])
disp('        ')
disp(['CRPS: ', num2str(crps),'    |     ',num2str(crps_ar) '    |     ', num2str(sigma(21)), '    |     ', num2str(t_val(21)), '       |     ',  num2str(Pval(21))])
disp('        ')
disp(['QuantS: ', num2str(quant),'  |     ',num2str(quant_ar) '   |     ', num2str(sigma(22)), '    |     ', num2str(t_val(22)), '      |     ',  num2str(Pval(22))])
disp('        ')
disp(['CLS: ', num2str(CLS),'       |     ',num2str(CLS_ar) '     |     ', num2str(sigma(23)), '    |     ', num2str(t_val(23)), '      |     ',  num2str(Pval(23))])
disp('        ')
disp(['CSL: ', num2str(CSL),'     |     ',num2str(CSL_ar) '     |     ', num2str(sigma(24)), '    |     ', num2str(t_val(24)), '      |     ',  num2str(Pval(24))])
disp('        ')
disp(['HS: ', num2str(HS),'      |     ',num2str(HS_ar) '     |     ', num2str(sigma(25)), '    |     ', num2str(t_val(25)), '       |     ',  num2str(Pval(25))])
disp('        ')
disp(['LCS: ', num2str(LCS),'     |     ',num2str(LCS_ar) '   |     ', num2str(sigma(26)), '    |     ', num2str(t_val(26)), '       |     ',  num2str(Pval(26))])
disp('        ')
disp('--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------')