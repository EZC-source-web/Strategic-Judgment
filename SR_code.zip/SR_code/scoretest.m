function [S_LM, pval_S_LM] = nScore_test(gamma1, gamma2, w, theta0,theta1,theta2, Ggamma1, Ggamma2, u)
% Compute the statistic S1 and its p-value for applications

sigmahat=sum(u.^2);
bar_w = X;    % Use the notation of the paper!
thetawGgamma1 = bar_w*lambda.*Ggamma1;
thetawGgamma2 = bar_w*lambda.*Ggamma2;
Z = [bar_w*lambda];
H = [thetawGgamma1, thetawGgamma2];
S_LM = 1/sigmahat*((u'*Z)*(pinv(Z'*Z - Z'*H*pinv(H'*H)*H'*Z))*(Z'*u));
%Compute the p-value according to the so found statistic:
pval_S_LM = 1-cdf('chi2', S_LM , 2);  
end