function y = cols(x)
% Returns the column dimension of x
% USE:  y = cols(x)
[y] = size(x);
end
