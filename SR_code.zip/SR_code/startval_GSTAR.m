% Function to compute starting values for a Generalized Smooth
% Transition Regression (STR). The algorith is based on a grid search over
% the parameters gamma1, gamma2 and c.
% Original version by MC. Medeiros, 2006.
% This version: EZC, June 30, 2013.
function [alphaf,betaf,lambdaf,gamma1f,gamma2f,cf]=startval_GSTAR(y,X,W,q,m,gamma1,gamma2,c)

% inputs:
% ------
% y: dependent variable.
% X: regressors.
% W: dummy regressors.
% q: transition variable.
% m: number of nonlinear terms (number of regimes - 1)
% gamma1: gamma1 values for the previous nonlinear terms.
% gamma2: gamma2 values for the previous nonlinear terms.
% c: c values for the previous nonlinear terms.

% outputs:
% -------
% alphaf: starting value for alpha.
% lambdaf: starting value for lambda.
% gamma1f: starting value for gamma1.
% gamma2f: starting value for gamma2
% cf: starting value for c.
% bestcost: cost function evaluated at the starting point.


bestcost=999999999;

[T,nX] = size(X);
nW     = size(W,2);

% Maximum and minimum values for gamma1
% ------------------------------------
maxgamma1  = 10;
mingamma1  = -10;
rategamma1 = 1;
% Maximum and minimum values for gamma1
% ------------------------------------
maxgamma2  = 10;
mingamma2  = -10;
rategamma2 = 1;

% Maximum and minumum values for c
% --------------------------------
minc=prctile(q,10);
maxc=prctile(q,90);
ratec=(maxc-minc)/200;
gamma1(m,1) = 0;
gamma2(m,1) = 0;
c(m,1) = 0;
for newgamma1=mingamma1:rategamma1:maxgamma1
    for newgamma2=mingamma2:rategamma2:maxgamma2
        for newc=minc:ratec:maxc
            gamma1(m,1) = newgamma1;
            gamma2(m,1) = newgamma2;
            c(m,1)     = newc;
            Z = [X W];
            [eta, h_stuk, MU_stuk, G_stuk] = G_stukel(q-c, gamma1, gamma2);
        for i=1:m
            fX(:,i) = G_stuk(:,i);
            Z       = [Z repmat(fX(:,i),1,nX).*X];
        end
        theta  = pinv(Z'*Z)*Z'*y;
        alpha  = theta(1:nX);
        if isempty(W)==1
            beta=[];
        else
            beta   = theta(nX+1:nX+nW);
        end
        lambda = reshape(theta(nX+nW+1:end),nX,m);
        if isempty(W)==1
            yhat   = X*alpha +  sum((fX*lambda').*X,2);
        else
            yhat   = X*alpha + W*beta + sum((fX*lambda').*X,2);
        end
        e      = y - yhat;
      	cost   = sum(e.^2)/T;
       	if cost<=bestcost
            bestcost = cost;
            gamma1f   = gamma1;
            gamma2f   = gamma2;
            cf       = c;
            alphaf   = alpha;
            betaf    = beta;
            lambdaf  = lambda;
        end
        end     
    end
end
