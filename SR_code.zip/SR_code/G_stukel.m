function [eta, h_stuk, MU_stuk, G_stuk] = G_stukel(eta, gamma1, gamma2)
% This function compute the Transition Function G for a GLSTAR model with the original Stukel parametrization.

%Define the Stukel function (Stukel (1988) fromula 2-3)
h11 = (gamma1^(-1)).*(exp(gamma1*abs(eta)) - 1); 
h12 = eta ;
h13 = (-gamma1^(-1))*log(1 - gamma1*abs(eta)) ; 

h21 = (-gamma2^(-1)).*(exp(gamma2*abs(eta)) - 1) ;
h22 = eta ;
h23 = (gamma2^(-1))*log(1 - gamma2*abs(eta)) ;
       
if gamma1 > 0
    h1 = h11;
elseif gamma1 == 0
    h1 = h12;
else h1 = h13;
end

if gamma2 > 0
    h2 = h21;
elseif gamma2 == 0
    h2 = h22 ;
else h2 = h23;
end

%Define: h_gamma, mu_gamma and G
h_stuk = ((eta) <=0).*(h2) + ((eta) >=0).*(h1); %This is the h_alpha function in Stukel, Fig 1a
MU_stuk = exp(h_stuk)./(1 + exp(h_stuk)); % This is the mu-transformation plotted in Stukel  Fig 1b
G_stuk = (1 + exp(-(h_stuk))).^(-1) ;%This is the TRANSITION FUNCTION equivalent of mu-transformed function in Stukel, Fig 1b
end