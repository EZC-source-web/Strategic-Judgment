function [qsr] = qscore(x,y)
[pdf1,xi] = ksdensity(x,'kernel','epanechnikov','function','pdf');
[pdf2,xi] = ksdensity(y,'kernel','epanechnikov','function','pdf');
qsr = 2*pdf1(:,50) - sum((pdf1-pdf2).^2);
end