function a = siglog(n)

a = 1 ./ (1 + exp(-n));
