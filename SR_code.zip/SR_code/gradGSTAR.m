function [ggamma1,ggamma2,gc]=gradGSTAR(PSI,X,q,lambda,dfX,m)

[gamma,c] = getpar(PSI);

for i=1:m
    ggamma1(:,i) = (X*lambda(:,i)).*(dfX(:,i).*(q-c(i)<0));
    ggamma2(:,i) = (X*lambda(:,i)).*(dfX(:,i).*(q-c(i)>0));
    gc(:,i)     = -(X*lambda(:,i)).*(gamma(i)*dfX(:,i));
end