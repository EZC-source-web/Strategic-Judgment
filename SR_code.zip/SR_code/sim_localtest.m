clear
clc

randn('state', 123456);
sigerr = .25; 
T = 100;
nsim = 1000;
eps = sqrt(sigerr)*randn(T,nsim);

%% STEP 0: Define the parameters
%Linear Part
phi0 = 0.0; 
phi1 = .8;  %SET 1.1 and 0.8
phi2 = -.7; %SET -.8 and -0.7
phi = [phi1 phi2]';
%Nonlinear Linear Part
theta0 = 0.02;
theta1 = -.9;  %SET -0.8 and -.9
theta2 = 0.795; %SET .695 and .795
theta = [theta1 theta2]';
%Slopes and location parameters
gamma = 10;
c=.02;
%Other parameter for simulation

alpha01 = 0.01; alpha05 = 0.05; alpha10 = 0.1;

d = 100; %Discard the first d simulations
%k=1; % scale constant for scoring rule
%Preallocate
y = zeros(T,1);
Y = zeros(T,nsim);
s =  zeros(T,1);
S = zeros(T,nsim);
P_LM1=zeros(1,nsim); P_LM2=zeros(1, nsim); P_LM3=zeros(1, nsim);
Beta = zeros(1, nsim);
Power = zeros(1, nsim);
%xi = linspace(-5,5,nsim);
%% STEP 1: SIMULATION  
for m=1:nsim
    for i= 3:T   %Assume an STAR(2)
    y(i) = (1-G(gamma*(y(i-1)-c)))*(phi0 + phi1*y(i-1) + phi2*y(i-2)) + (G(gamma*(y(i-1)-c)))*(theta0 + theta1*y(i-1) + theta2*y(i-2))+ eps(i,m);
    s(i) = AveLogScore(median(y),y(i-1),mean(y),var(y));
    end
   
[hat_z, h01, h02, h03, z_nl, S_LM1, S_LM2, S_LM3, pval_LM1, pval_LM2, pval_LM3]= L_test(y, phi0, phi, theta0, theta, gamma, T,s, c);
Y(:,m)=y;
S(:,m)=s;
%Add and store the three statistics
P_LM1(1,m) = pval_LM1;
P_LM2(1,m) = pval_LM2;
P_LM3(1,m) = pval_LM3;
end

%plot(y)
Y(:,1:d)=[];
P_LM1(:,1:d)=[]; P_LM2(:,1:d)=[];P_LM3(:,1:d)=[];
%Define the Empirical P-value
EPval_LM1= mean(P_LM1); EPval_LM2= mean(P_LM2); EPval_LM3= mean(P_LM3);
%Define the Type II error (Beta) 
NS=1:size(Y,2);
Beta_P01_LM1=cumsum(P_LM1>alpha01)./NS; Beta_P01_LM2=cumsum(P_LM2>alpha01)./NS; Beta_P01_LM3=cumsum(P_LM3>alpha01)./NS; 
Beta_P05_LM1=cumsum(P_LM1>alpha05)./NS; Beta_P05_LM2=cumsum(P_LM2>alpha05)./NS; Beta_P05_LM3=cumsum(P_LM3>alpha05)./NS;
Beta_P10_LM1=cumsum(P_LM1>alpha10)./NS; Beta_P10_LM2=cumsum(P_LM2>alpha10)./NS; Beta_P10_LM3=cumsum(P_LM3>alpha10)./NS;
%  Power
Power_P01_LM1 = 1-Beta_P01_LM1;  Power_P01_LM2 = 1-Beta_P01_LM2; Power_P01_LM3 = 1-Beta_P01_LM3;
Power_P05_LM1 = 1-Beta_P05_LM1;  Power_P05_LM2 = 1-Beta_P05_LM2; Power_P05_LM3 = 1-Beta_P05_LM3;
Power_P10_LM1 = 1-Beta_P10_LM1;  Power_P10_LM2 = 1-Beta_P10_LM2; Power_P10_LM3 = 1-Beta_P10_LM3;
%  Empirical Beta
EBeta_P01_LM1 = mean(Beta_P01_LM1); EBeta_P01_LM2 = mean(Beta_P01_LM2); EBeta_P01_LM3 = mean(Beta_P01_LM3);
EBeta_P05_LM1 = mean(Beta_P05_LM1); EBeta_P05_LM2 = mean(Beta_P05_LM2); EBeta_P05_LM3 = mean(Beta_P05_LM3);
EBeta_P10_LM1 = mean(Beta_P10_LM1); EBeta_P10_LM2 = mean(Beta_P10_LM2); EBeta_P10_LM3 = mean(Beta_P10_LM3);
%  Empirical Power
EP_01_LM1 = mean(Power_P01_LM1); EP_01_LM2 = mean(Power_P01_LM2); EP_01_LM3 = mean(Power_P01_LM3);
EP_05_LM1 = mean(Power_P05_LM1); EP_05_LM2 = mean(Power_P05_LM2); EP_05_LM3 = mean(Power_P05_LM3);
EP_10_LM1 = mean(Power_P10_LM1); EP_10_LM2 = mean(Power_P10_LM2); EP_10_LM3 = mean(Power_P10_LM3);

%%%% PLOT THE RESULTS %%%%%%%%
disp('***************************************************************************************************')
disp('                                      Monte Carlo Results                                          ')
disp('***************************************************************************************************')
disp('---------------------------------------------------------------------------------------------------')
disp('                                          alpha = 0.01                                             ')
disp('---------------------------------------------------------------------------------------------------')
disp('               LM_01           ||            LM_02           ||            LM_03             ')
disp('-------------------------------||----------------------------||------------------------------')
disp(' Empirical  |  Emp.   |   Emp. ||   Emp   |  Emp.  |   Emp.  ||   Emp   |  Emp.  |   Emp.   ')
disp('  p-value   |  Beta   |  Power || p-value |  Beta  |  Power  || p-value |  Beta  |  Power   ')
disp('    ------  | ------  | ------ || ------  | ------ |  ------ || ------- | ------ |  ------  ')
disp( [EPval_LM1 EBeta_P01_LM1 EP_01_LM1 EPval_LM2 EBeta_P01_LM2 EP_01_LM2 EPval_LM3 EBeta_P01_LM3 EP_01_LM3])
disp('---------------------------------------------------------------------------------------------------')
disp('                                          alpha = 0.05                                             ')
disp('---------------------------------------------------------------------------------------------------')
disp('               LM_01           ||            LM_02           ||             LM_03             ')
disp('------------------------------ ||----------------------------||-------------------------------')
disp(' Empirical  |  Emp.   |   Emp. ||   Emp   |  Emp.  |   Emp.  ||  Emp    |  Emp.  |   Emp.  ')
disp('  p-value   |  Beta   |  Power || p-value |  Beta  |  Power  || p-value |  Beta  |  Power  ')
disp('    ------  | ------  | ------ || ------  | ------ |  ------ || ------- | ------ |  ------ ')
disp( [EPval_LM1 EBeta_P05_LM1 EP_05_LM1 EPval_LM2 EBeta_P05_LM2 EP_05_LM2 EPval_LM3 EBeta_P05_LM3 EP_05_LM3])
disp('---------------------------------------------------------------------------------------------------')
disp('                                        alpha = 0.10                                               ')
disp('---------------------------------------------------------------------------------------------------')
disp('               LM_01           ||           LM_02            ||            LM_03             ')
disp('------------------------------ ||----------------------------||------------------------------')
disp(' Empirical  |  Emp.   |   Emp. ||   Emp   |  Emp.  |  Emp.   ||   Emp   |  Emp.  |   Emp.   ')
disp('  p-value   |  Beta   |  Power || p-value |  Beta  | Power   || p-value |  Beta  |  Power   ')
disp('    ------  | ------  | ------ || ------  | ------ | ------  || ------- | ------ |  ------   ')
disp( [EPval_LM1 EBeta_P10_LM1 EP_10_LM1 EPval_LM2 EBeta_P10_LM2 EP_10_LM2 EPval_LM3 EBeta_P10_LM3 EP_10_LM3])
disp('----------------------------------------------------------------------------------------------------')

