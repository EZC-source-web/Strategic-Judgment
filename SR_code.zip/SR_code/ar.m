function [yhat,ehat,sigma,se]=ar(X,x)
b     = inv(X'*X)*X'*x;
yhat  = X*b;
ehat  = x - yhat; 
sigma = std(ehat);
se    = sigma*sqrt(diag(inv(X'*X)));
end