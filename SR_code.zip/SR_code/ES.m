function [ES] = ES(x,mu,sigma,beta)
ES = .5 + norm(pdf('norm',x,mu,sigma)-cdf('norm',x,mu,sigma))^beta - norm((mu - x))^beta;
end