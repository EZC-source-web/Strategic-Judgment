function m=stdc(x)
% This function gets standard deviation of each column
%
m=std(x);
if size(m,2)>1;
   m=m';
end
return
