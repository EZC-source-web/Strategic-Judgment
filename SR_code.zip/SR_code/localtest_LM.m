function [LM, pval_LM] = localtest_LM(y_gstar, T, s)
%This funtion computes the SLT-type test for locality under dynamic
%asymmetry (cf. EZC 2013).
%
%Step 0: Define the covariate matrix under the NULL HYPOTHESIS OF LINEARITY
hat_z = -[ones(size(y_gstar,1),1),lag(y_gstar,1),lag(y_gstar,2)];
beta10 = phi0 - 0.25*c*theta0;
e = [1, 0]';
Beta1 = phi - 0.25*c*theta + 0.25*theta0*e;
beta_tilde = [beta10, Beta1']';
z_lin = hat_z*beta_tilde; 

%Step 0-bis: define the matrix of augmented auxiliary model in case of
%asymmetry
h0 = [hat_z(:,2:end).*repmat(s,1,2),hat_z(:,2:end).*repmat(s.^2,1,2),hat_z(:,2:end).*repmat(s.^3,1,2)];

%Step 0-ter: Define the covariate matrix under the ALTERNATIVE HYPOTHESIS OF
%ASYMMETRY
z_nl = [z_lin, h0];

%Step 1: regress y on the covariate matrix under the null hp (THAT IS, 
%ESTIMATE A LINEAR MODEL given that the series is nonlinar) and compute the
%SSR0
results0=ols(y_gstar, z_lin);
RES0=[results0(1:end).resid];
SSR0=sum(RES0.^2);
sigma20 = (1/T)*SSR0;
    
%Step 2: Regress y on the COVARIANCE MATRIX UNDER
%ALTERNATIVE (that is estimate the true nonlinear model) and compute the
%SSR1
results1 = ols(RES0, z_nl);
RES1 = [results1(1:end).resid];
SSR1 = sum(RES1.^2);
sigma21 = (1/T)*SSR1;

%Step 3: built the test statistics LM2 (see T2010) using (F-version) and 
%the CDF and the p-value  for each draws
Gamma = [gamma1, gamma2, size(c,2)];
n = length(Gamma);
p = length(theta);
%S2 = (SSR0-SSR1)/sigma21;
LM = ((SSR0-SSR1)/(2*p+n))/(SSR1/(T-2*p-n));
%CDF = cdf('chi2', S2, n);
CDF = cdf('f', LM, 2*p+n, T-2*p-n);
pval_LM = 1-CDF;
end