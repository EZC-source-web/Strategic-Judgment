function [logS] = logScore(y, T)
[f,xi] = ksdensity(y,'kernel','epanechnikov','function','pdf');
pdf1 = f(:,50);
logS = -(1/T)*sum(log(pdf1));
end