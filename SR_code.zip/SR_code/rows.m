function y = rows(x)
% This function returns the row dimension of x
% USE:  y = rows(x)
[y,yy] = size(x);
end
