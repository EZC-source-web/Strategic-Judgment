function [alpha,beta,lambda,gamma1,gamma2,c,fX,yhat,ehat,G,sigma,se]=parestGSTARlm(y,X,W,q,T,nX,nW,m,gamma1,gamma2,c)

% Compute starting values
% -----------------------
[alphaf,betaf,lambdaf,gamma1f,gamma2f,cf]=startval_GSTAR(y,X,W,q,m,gamma1,gamma2,c);

PSI = setparGSTAR(gamma1f,gamma2f,cf);

options = optimset('Display','off','Jacobian','on','MaxFunEvals',1e10,...
        'LargeScale','off','MaxIter',4000,'TolFun',1e-10,...
        'DerivativeCheck','off','LevenbergMarquardt','on',...
        'LineSearchType','cubicpoly','TolX',1e-10,'TolCon',1e-10);
 
PSI = fmincon('msecost_GSTAR',PSI,[],[],[],[],...
             [zeros(m,1);ones(m,1)*prctile(q,10)],...
             [inf(m,1);ones(m,1)*prctile(q,90)],[],options,...
              y,X,W,q,m);

[gamma1,gamma2,c] = getpar_GSTAR(PSI);

aux   = [gamma1 gamma2 c];
aux   = sortrows(aux,3);
gamma1 = aux(:,1);
gamma2 = aux(:,2);
c     = aux(:,3);

Z = [X W];
fX = zeros(T,m);
dfX = zeros(T,m);
[eta, h_stuk, MU_stuk, G_stuk] = G_stukel(q-c, gamma1, gamma2);
for i=1:m
    fX(:,i)  = siglog(h_stuk(:,i));
    dfX(:,i) = dsiglog(fX(:,i));
    Z        = [Z repmat(fX(:,i),1,nX).*X];
end
theta  = pinv(Z'*Z)*Z'*y;
alpha  = theta(1:nX);
if isempty(W)==1
    beta=[];
else
    beta   = theta(nX+1:nX+nW);
end
lambda = reshape(theta(nX+nW+1:end),nX,m);
if isempty(W)==1
    yhat   = X*alpha + sum((fX*lambda').*X,2);
else
    yhat   = X*alpha + W*beta + sum((fX*lambda').*X,2);
end; 
ehat   = y - yhat;

PSI = setparGSTAR(gamma1,gamma2,c);

[ggamma1,ggamma2,gc] = gradGSTAR(PSI,X,q,lambda,dfX,m);

galpha  = X;
glambda = Z(:,nX+nW+1:end);
gbeta   = W;
G = [galpha,gbeta,glambda,ggamma1,ggamma2,gc];
sigma  = std(ehat);
se     = sigma*sqrt(diag(pinv(G'*G)));
