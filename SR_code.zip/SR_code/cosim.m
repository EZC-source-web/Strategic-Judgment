function [x] = cosim(nd)
% This function computes the deterministic cycle given a sequence t
t=seqa(1,1,nd);
x=sin(t)+cos(1.5*t);
end 