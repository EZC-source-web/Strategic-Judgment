function m=meanc(x)
% This function gets the mean of each column
m=mean(x);
if size(m,2)>1
   m=m';
end
return
