%***********************************************************************************************************/
%*                                                                                                         */
%*                             Modified BBQ algorithm with Scoring Rules                                   */ 
%*                                                                                                         */ 
%*  Computes turning points and imposes restrictions in one step according to Harding and Pagan 2002 (JME) */
%*  by taking in account for Scoring Rules derived from an STAR specification in the dating alghorithm 
%*                                                                                                         */
%*    NB: rule is peak greater than turnphase on either side, trough less than turnphase on either side.   */ 
%*    Restriction: Phase quarters/months, Cycle  quarters/months Alternating Troughs and Peaks,            */ 
%*                  if two peaks(troughs) in a row chooses highest(lowest), Trough must be                 */ 
%*                  lower then preceeding peak, and No truning point within phase length                   */ 
%*                  of end points                                                                          */ 
%*                                                                                                         */  
%*    Date:                                                                                                */
%*    ORIGINAL VERSION: James Engel (2005) - Code modified from Adrian Pagan and Don Harding               */  
%*                      BBQ code                                                                          */ 
%*    THIS version: Emilio Zanetti Chini (2017)                              
%*         
%*************************************************************************/

clc;
clear
clock1 = clock;
importfile('/Users/emiliozanettichini/Desktop/WP/SR/Code/Data_q.xls');

%% STEP 0: Prelude

% Set the number of replications. 
nrep = 1;        % Set nrep=1 if analysing real data; set nrep >> 1 for Monte Carlo experiments
complete = 1;  % switch: 1 - only use complete cycles,0-use incomplete cycles (excess still on complete cycle) 

% Set the cycle's "censoring rules" (see also the function "rowall.m").
turnphase = 1;  % number of quartes (months) before the peak    
phase = 2;      % the duration of a phase have to be at least 9 months (3 qurters)         
cycle = 5;      % local peak set at t when y_t > y_t+k, k = ?        
thresh = 7.5;    % threshold  

%Set the SCORING RULE 
flagscore=1; %Set flag=1 if you want activate the scoring rule, 0 otherwise

% Select the data
freq = 1;                % Frequency: 1 for quarterly, 2 for monthly %
ndfy = 1947;             % First Year of data set %
ndfm = 2;                % First quarter/month of data set %
ndly = 2013;             % Last Year of data set %
ndlm = 1;                % Last quarter/month of data set %

% change of variables
nsfy=ndfy; nsfm=ndfm; nsly=ndly; nslm=ndlm;  

% Set the number of data points and change the name of the variable
if freq==1;
nd= 4*(ndly-1-ndfy) + (5-ndfm) + (ndlm);     
elseif freq==2
nd= 12*(ndly-1-ndfy) + (13-ndfm) + (ndlm); 
end
nn=nd;  %Change of variables

%Set seed
iseed=7654;

%Preallocation 
notentp=0;durs=zeros(nd,1);bcp5=zeros(nd,1);bct5=zeros(nd,1);st=zeros(nd,1);
pds=zeros(1,1);pdsa=zeros(1,1); bvec=zeros(nd,1);pdmmat=zeros(nrep+1,1);
tdmmat=zeros(nrep+1,1); pdmmata=zeros(nrep,1);pdcv=0;tdcv=0;pacv=0;tacv=0;
pdm=0;pdma=0;tdm=0;tdma=0;pdcm=0;tdcm=0;pdem=0;tdem=0;tdema=0;pdema=0;
epcv=0;etcv=0;nbt=0;nbp=0;iter=1;

disp('Number of draws')
disp(nrep)

%% STEP 1: START THE ALGORITHM
while iter <= nrep;
nd=nn;

%REAL DATA - has to be in LN form unless log command is not commented out
x = IIP;
%x = log(x); 
x = log(x)- lag(log(x),1); x = x(2:end);
T = length(x);

%SIMULATED DATA - place model m file in working directory
% Two possibilities: 
% 1) cosim.m is a deterministic sinus-cosine function and 
% 2) usar.m is a simulated linear AR process

%x = cosim(nd);
%[x,iseed] = usar(iseed,nd);
%T = length(x);


%Select the AR order via BIC
O = ones(length(x),1);
p = mbic(x, O, lag(x,1), 24);

%% STEP 2: ESTIMATE A STAR model
%Set the inputs for function "mrstar.m".
X = [ones(T,1), lag(x,1) lag(x,2) lag(x,3) lag(x,4) lag(x,5)];
W = [];
nX = size(X,2);
nW = size(W,2);
M = [];
q = lag(x,4);
rob = 1;
flag = 1;
sig = 0.05;
%Call the function
[yhat,ehat,alpha,beta,lambda,gamma,c,se,G,fX,pvalue] = mrstar(x,X,W,q,T,nX,nW,M,rob,flag,sig);
disp('--------------------------------------------------')
disp('            Estimated Nonlinear model')
disp('--------------------------------------------------')
disp('Linear parameters')
disp([ alpha])
disp('NON-Linear parameters')
disp([ lambda])
disp('gamma  ')
disp([ gamma])
disp(' c ')
disp([ c ])
disp(' SE ')
disp([ se ])

%Forecast
H = 60;   % number of forecast periods
S = 100;  % number of simulations
fore = zeros(H,S);

for h=1:H
    randn('state',iseed);
    fore(h,:) = yhat(T)+((randn(1,S).*h)./S); 
    y_point = (1/S).*sum(fore,2);
end
y_point = (1/S).*sum(fore,2);
hist=yhat;

% Copute the scoring rules
a=0.1;
aleph=0.5;
k=1;
d=2;
beta=0.3;
   %if gamma=0, the weights (w4) in CLS are computed like a threshold function instead

[qsr,wps,wps1,wps2,wps3,wps4,wps5,pseudosph,wpsph,wpsph1,wpsph2,wpsph3,...
    wpsph4,wpsph5,logS,IntS,TsallisS,ES,GES,PSpectrum,crps,quant,...
    CLS,CSL,HS,LCS]=scorings(fore,h,yhat,thresh,a,aleph,k,d,beta,gamma,c,flagscore); 

SR=[qsr,wps,wps1,wps2,wps3,wps4,wps5,pseudosph,wpsph,wpsph1,wpsph2,wpsph3,...
    wpsph4,wpsph5,logS,IntS,TsallisS,ES,GES,PSpectrum,crps,quant,...
    CLS,CSL,HS,LCS];
%% STEP 3: Calculates turning points with restrictions on the estimated model
%**************************************************************************  
% Calculate peak to trough durations and amplitude
% p: peaks (that is contractions), 
% t: troughs (expansions);
% pd (td): peak (troughs) durations; 
% pda (tda): peaks (troughs) amplitude; 
% pdc (tdc): cumulated movements within pahses; 
% pde (tde): excess cumulated movements in peaks (troughs). 
% NOTE: 
% It is measured differently to avoid case that amps is close to zero in 
% part of the cycle so that denom can become negative. So we use cumulated 
% movements as denomination now vs triangle in early paper
%**************************************************************************
y=zeros(nd,1);c=zeros(nd,1);in=zeros(nd,1);
Sr=length(SR);
i=1;  sr=SR(i);        %Select the scoring rule in the SR vector and repete if you want to reproduce the table (put 1, 3, 9, 15, 21 for figures in paper)
[bcp5,bct5,nbp,nbt]=rawall(yhat,turnphase,nd,phase,cycle,thresh,sr);   
if nbp+nbt<=2;
notentp=notentp+1;
else
    ntr=nbt;
    npk=nbp;
    nr=[nbt;nbp];
    nv=max(nr); 
    pdc=zeros(nv,1);
    tdc=zeros(nv,1); 

if bcp5(1,1) < bct5(1,1);       % Peaks-to-Troughs
    nr=[nbt;nbp];
    r=nbt;
    pd=bct5(1:r,1)-bcp5(1:r,1);
    pda=x(bct5(1:r,1))-x(bcp5(1:r,1));
    k=1;
    while k<=r;
        pdc(k)=sumc(x(bcp5(k,1):bct5(k,1),1)-x(bcp5(k,1),1));
        k=k+1;
    end
else                             % Troughs-to-Peaks
    r=nbt-1;
    pd=bct5(2:r+1,1)-bcp5(1:r,1);
    pda=x(bct5(2:r+1,1))-x(bcp5(1:r,1));
    k=1;
    while k<=r;
        pdc(k)=sumc(x(bcp5(k,1):bct5(k+1,1),1)-x(bcp5(k,1),1));         
        k=k+1;
    end
    r1=r;
end

% Calculate durations and amplitudes 
if bct5(1,1) < bcp5(1,1);        %  Troughs-to-Peaks 
    r=nbp;
    td=bcp5(1:r,1)-bct5(1:r,1);
    tda=x(bcp5(1:r,1))-x(bct5(1:r,1));
    k=1;
    while k<=r;
        tdc(k)=sumc(x(bct5(k,1):bcp5(k,1),1)-x(bct5(k,1),1));
        k=k+1;
    end
else                             %  Peaks-to-Throughs 
    r=nbp-1;
    td=bcp5(2:r+1,1)-bct5(1:r,1);
    tda=x(bcp5(2:r+1,1))-x(bct5(1:r,1));
    k=1;
    while k<=r;
        tdc(k)=sumc(x(bct5(k,1):bcp5(k+1,1),1)-x(bct5(k,1),1));
        k=k+1;
    end
end
pdc=pdc(1:rows(pd));
tdc=tdc(1:rows(td));

% Compute the excesses as percentage of triangle area
zpa=(pd.*pda)/2;
pde=100*(pdc-zpa-.5*pda)./zpa;

pdea=100*(pdc-((pd.*pda)/2))./zpa;

zta=(td.*tda)/2;
tde=100*(tdc-zta-.5*tda)./zta;
                
tdea=100*(tdc-((td.*tda)/2))./zta;
                 
% State what happen if using complete rather than incomplete cycles.
if complete == 0;  % switch: 1-only use complete cycles,0-use incomplete cycles (excess still on complete cycle)
    bct5u=bct5;
    bcp5u=bcp5;
    if bcp5(1,1) < bct5(1,1);          % modifies code to include incomplete cycles %
        bct5u  = [1;bct5];
    elseif 	bct5(1,1) < bcp5(1,1);
        bcp5u = [1;bcp5]; 
    end
    nbtu = rows(bct5u);
    nbpu = rows(bcp5u);
    bcp5u=zeros(nv,1); 
    bct5u=zeros(nv,1); 
    if bcp5u(nbpu,1) < bct5u(nbtu,1)   % modifies code to include incomplete cycles %
        bcp5u  = [bcp5u;nd];
    elseif 	bct5u(nbt,1) < bcp5u(nbp,1)
        bct5u = [bct5u;nd]; 
    end
    ntr=rows(bct5u);npk=rows(bcp5u);
    nr=[ntr;npk];
    nv=max(nr);
    pdc=zeros(nv,1);
    tdc=zeros(nv,1);
    if bcp5u(1,1) < bct5u(1,1)        % Peaks-to-Troughs 
        nr=[ntr;npk];
        r=ntr;
        pd=bct5u(1:r,1)-bcp5u(1:r,1);
        pda=x(bct5u(1:r,1))-x(bcp5u(1:r,1));
        k=1;
        while k<=r
            pdc(k)=sumc(x(bcp5u(k,1):bct5u(k,1),1)-x(bcp5u(k,1),1));
            k=k+1;
        end
    else                             % Troughs-to-Peaks
        r=ntr-1;
        pd=bct5u(2:r+1,1)-bcp5u(1:r,1);
        pda=x(bct5u(2:r+1,1))-x(bcp5u(1:r,1));
        k=1;
        while k<=r
            pdc(k)=sumc(x(bcp5u(k,1):bct5u(k+1,1),1)-x(bcp5u(k,1),1));         
            k=k+1;
        end
        r1=r;
    end
    
% Calculate trough to peak durations & amplitudes 
if bct5u(1,1) < bcp5u(1,1);        %  Troughs-to-Peaks 
    r=npk;
    td=bcp5u(1:r,1)-bct5u(1:r,1);
    tda=x(bcp5u(1:r,1))-x(bct5u(1:r,1));
    k=1;
    while k<=r
        tdc(k)=sumc(x(bct5u(k,1):bcp5u(k,1),1)-x(bct5u(k,1),1));
        k=k+1;
    end
else                                % Peaks-to-Troughs 
    r=npk-1;
    td=bcp5u(2:r+1,1)-bct5u(1:r,1);
    tda=x(bcp5u(2:r+1,1))-x(bct5u(1:r,1));
    k=1;
    while k<=r
        tdc(k)=sumc(x(bct5u(k,1):bcp5u(k+1,1),1)-x(bct5u(k,1),1));
        k=k+1;
    end
end
pdc=pdc(1:rows(pd));
tdc=tdc(1:rows(td));
end
       
%% STEP 3: CUMULATE.
% When nrep=1 then gives raw data, otherwsise sums over monte carlo amounts
pdcv=pdcv+stdc(pd)/meanc(pd);  %  cumulated values of peak duration
tdcv=tdcv+stdc(td)/meanc(td);  %                   of trough duration
pacv=pacv+stdc(pda)/meanc(pda);%                   of peak amplitude
tacv=tacv+stdc(tda)/meanc(tda);%                   of trough amplitude
epcv = epcv + stdc(pde)/meanc(pde); %              of excess peaks
etcv=etcv+stdc(tde)/meanc(tde);     %              of excess trough

pdm=pdm+meanc(pd);          % P-T durations 
pdma=pdma+meanc(pda);

tdm=tdm+meanc(td);          % T-P durations 
tdma=tdma+meanc(tda);

pdcm=pdcm+meanc(pdc);       % cumulative durations 
tdcm=tdcm+meanc(tdc);

tdem=tdem+meanc(tde);       % excess 
tdema=tdema+meanc(tdea);
pdem=pdem+meanc(pde);
pdema=pdema+meanc(pdea);               
end

if nrep==1.&&(nbp+nbt>2)

disp('peaks at')
disp(bcp5(1:nbp))
disp('troughs at')
disp(bct5(1:nbt))
end

pdmmat(iter+1)=pdm-pdmmat(iter);
tdmmat(iter+1)=tdm-tdmmat(iter);
iter=iter+1;
nrep1=nrep-notentp;
%Summarize the business cycle statistics in one vector
BCS=[ pdm/nrep1  tdm/nrep1  pdma/nrep1  tdma/nrep1  pdcm/nrep1 tdcm/nrep1 ...                      
    pdem/nrep1 tdem/nrep1 pdcv/nrep1  tdcv/nrep1   pacv/nrep1  tacv/nrep1 epcv/nrep1  etcv/nrep1];



%% STEP 4: COMPLETE THE ALGORITHM
if nrep==1.&&(nbp+nbt>2);
    %remove below if want states ...
    t=zeros(nd,1);
    [st]=states(bcp5,bct5,nbp,nbt,nd);
    %determine obs in which states have been completed...
    na=min([bct5(1);bcp5(1)])';
    nb=max([bct5(nbt);bcp5(nbp)])';
    nb=nb - na + 1;
    z=[x(na:nb) st(na:nb)];
    z1= [x st];
    disp('dated series')
    disp(z1)
end
nrep1=nrep-notentp;

%% STEP 5: SHOW THE RESULTS 
disp('----------------------------------------')
disp('SCORING RULES for the ESTIMATED MODEL')
disp('        ')
disp(['QSR: ', num2str(qsr)])
disp('        ')
disp(['WPowerS: ', num2str(wps)])
disp('        ')
disp(['WPowerS (aleph=-1): ', num2str(wps1)])
disp('        ')
disp(['WPowerS (aleph=0): ', num2str(wps2)])
disp('        ')
disp(['WPowerS (aleph=1/2): ', num2str(wps3)])
disp('        ')
disp(['WPowerS (aleph=1): ', num2str(wps4)])
disp('        ')
disp(['WPowerS (aleph=2): ', num2str(wps5)])
disp('        ')
disp(['PseudoSph: ', num2str(pseudosph)])
disp('        ')
disp(['WPseudoSph: ', num2str(wpsph)])
disp('        ')
disp(['WPseudoSph (aleph=-1): ', num2str(wpsph1)])
disp('        ')
disp(['WPseudoSph (aleph=0): ', num2str(wpsph2)])
disp('        ')
disp(['WPseudoSph (aleph=1/2): ', num2str(wpsph3)])
disp('        ')
disp(['WPseudoSph (aleph=1): ', num2str(wpsph4)])
disp('        ')
disp(['WPseudoSph (aleph=2): ', num2str(wpsph5)])
disp('        ')
disp(['LogS: ', num2str(logS)])
disp('        ')
disp(['IntS: ', num2str(IntS)])
disp('        ')
disp(['TsallisS: ', num2str(TsallisS)])
disp('        ')
disp(['ES: ', num2str(ES)])
disp('        ')
disp(['GES: ', num2str(GES)])
disp('        ')
disp(['PseudoSpectrum: ', num2str(PSpectrum)])
disp('        ')
disp(['CRPS: ', num2str(crps)])
disp('        ')
disp(['QuantS: ', num2str(quant)])
disp('        ')
disp(['CLS: ', num2str(CLS)])
disp('        ')
disp(['CSL: ', num2str(CSL)])
disp('        ')
disp(['HS: ', num2str(HS)])
disp('        ')
disp(['LCS: ', num2str(LCS)])
disp('        ')
disp('---------------------------------------------')
disp('****************************')
disp('****************************')
disp('STATISTICS on AVERAGE CYCLE')
disp('---------------------------')
disp('                           ')
disp('   Scoring  |     Duration     |      Amplitude    |  Cum. movements   | ExMov in % tr area | Coef. Var. of Dur| Coef. Var of Amplt.| Coef.Var of Excss ')
disp('     Rule   | contr. | expans. |  contr. | expans. |  contr. | expans. |  contr.  | expans. | contr. | expans. |   contr. | expans. | contr. | expans.')
disp('  --------  | -------  ------  |  ------   ------  |  ------   ------  |  -------   ------- | ------    ------ |  ------    ------  | ------    ------')
disp([SR(i) BCS])
disp('')
disp('--------------------------------------------------')
disp('        ')
disp('number of its skipped since no peaks+troughs<=2')
disp(notentp)
pa=sortrows(pdmmat,1);
pb=sortrows(tdmmat,1);

end

%PLOT THE RESULTING FIGURE
figure(1)
% Select a starting date:
startDate = datenum('02-01-1947');
% Select an ending date:
endDate = datenum('02-01-2013');
% Create xdata to correspond to the number of 
% months between the start and end dates:
xData = linspace(startDate,endDate,T);
% For this example, plot random data:
plot(xData,z1)
% Convert the x tick labels to month names, keeping
% the limits of sample by using the 'keeplimits'
% option:
datetick('x','YYYY-QQ','keeplimits')
hold on
figure(2)
% Select a starting date:
startDate = datenum('02-01-1947');
% Select an ending date:
endDate = datenum('02-01-2013');
% Create xdata to correspond to the number of 
% months between the start and end dates:
xData = linspace(startDate,endDate,T);
% For this example, plot random data:
plot(xData,x,xData,yhat,xData,z1)
datetick('x','YYYY-QQ','keeplimits')
hold on
figure(2)
% Select a starting date:
startDate = datenum('02-01-1947');
% Select an ending date:
endDate = datenum('02-01-2013');
% Create xdata to correspond to the number of 
% months between the start and end dates:
xData = linspace(startDate,endDate,T);
% For this example, plot random data:
plot(xData,z1)
% Convert the x tick labels to month names, keeping
% the limits of sample by using the 'keeplimits'
% option:
datetick('x','YYYY-QQ','keeplimits')
[matm, mat_quant] = FanChart(fore,hist);
datetick('x','YYYY-QQ','keeplimits')
hold off

figure(3)
plot(sort(q),sort(fX),'o')
hold on
figure(4)
plot(1:T,fX,'o-','LineWidth',1)
%datetick('x','YYYY-QQ','keeplimits')

clock2=clock;
timerun = clock2-clock1;
disp('running time')
disp(etime(clock2,clock1))