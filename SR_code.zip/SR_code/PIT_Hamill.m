clc;
clear
iseed = 12345;
randn('state', iseed);
R = 60;
pmax = 4;
%% STEP 0: Define the parameters
% Linear part
phi0 = 0.0;
phi1 = 0.9;
phi2 = -0.795;
% NON-Linear part
theta0 = 0.01;
theta1 = 0.6;
theta2 = 0.4;
% Slope parameters
gamma1 = 200;
gamma2 = -100;
% Other parameters
T = 265;
%alpha01 = 0.01; alpha05 = 0.05; alpha10 = 0.1;
sigerr1 = .2;
sigerr2 = 1.5;
%
%% STEP 1: INITIALIZATION
%Generate a linear AR in order to have w which is required for G and the
%Hessian
[y, eps, phi, w, u_l] = sim_nAR(phi0, phi1, phi2, T , sigerr1);
p = T-length(y);
%Generate G
[theta, eta, s, c, eta_t, h, mu, G] = sim_G_glstar1(phi0, phi1, phi2, theta0, theta1, theta2, gamma1, gamma2, y, T);
%
%Build up the elements of the Score and Hessian (for whom I need only the
%parameters gamma1 gamma2, T, eta and eta_t which in turns are function
%of the Linear AR model previously defined.
[Ggamma1] = Ggamma1(gamma1, gamma2, h, eta, eta_t, T);
[Ggamma2] = Ggamma2(gamma1, gamma2, h, eta, eta_t, T);
[Gc] = Gc(gamma1, gamma2, h, eta, eta_t, T);
eps1 = eps(p+1:T);

%Step 2.a: Generate a linear AR in order to have w which is required for G 
%and the Hessian 
[y, eps, phi, w, u_l] = sim_nAR(phi0, phi1, phi2, T , sigerr1);
%
%Step 2.b: Generate the nonlinear function G
[theta, eta, s, c, eta_t, h, mu, G]=sim_G_glstar1(phi0, phi1, phi2, theta0, theta1, theta2, gamma1, gamma2, y, T);
%
%Step 2.c: Generate the NON-LINEAR part of the process in order to have w 
%which is required for G and the Hessian
[y_nl, u_nl] = sim_nlAR(theta0, theta, G, T, sigerr2);

%Step 2.d: Define the GLSTAR1 as the sum of the Linear AR + Nonlinear AR 
% previously defined
[y_gstar, u, sigma2_hat, sigma_hat] = nsim_GLSTAR1(T, y, y_nl, u_nl);
bar_z = [lag(y,1), lag(y,2)]';
Z = [ones(1,length(bar_z))', bar_z']';
%
% STEP 2.e: DEFINE THE  GSTAR as the sum of the Linear AR + Nonlinear AR 
%previously defined
[y_gstar, u, sigma2_hat, sigma_hat] = nsim_GLSTAR1(T, y, y_nl, u_nl);
%
x=lag(y,2);
qn = floor(R^(1/4));
h = 1;
T=length(y_gstar);

% STEP 3. Creates matrices to store the forecasts
densforecast = zeros(size(y_gstar,1),1)';
densforecast_lin = zeros(size(y,1),1)';
densforecast_gstar = zeros(size(y_gstar,1),1)';
 
   %% COMPUTE PIT 
for i = R:(T-1)
    y_hamill = y_gstar - y;
roll_y = y_hamill(i-R+1:i,:);
roll_x = x(i-R+1:i,:);
  
l = mbic(roll_y,ones(R,1),roll_x, pmax);

rgr = ones(R-l+1,1);
for j = 1:l
    rgr = [rgr roll_x(l-j+1:end-j+1,:)];
end

[beta betaint e] = regress(roll_y(l:end,:),rgr);
sige = nw(e,qn);
        
z = [1 x(i+1,:) rgr(end,2:end-1)];
densforecast_lin(1,i-R+1) = normcdf(y(i+1,1),z*beta,sige);
densforecast_gstar(1,i-R+1) = normcdf(y_gstar(i+1,1),z*beta,sige);

end
%NS = 1:size(densforecast,2);
%densforecast = sum(cleanNaN(densforecast(:,l+1:end)),2)./NS(1,1:size(cleanNaN(densforecast(:,l+1:end)),2));
densforecast = densforecast_lin(:,l+1:end)./ densforecast_gstar(:,l+1:end);

%Figure 1
bin = 5; m = size(densforecast,2);
fn1 = figure;
hs = histc(densforecast,0:1/bin:1);
bar(0:1/bin:1,hs./m,'histc')
xlim([0 1])
ylim([0 .5])
title('PIT for Hamill Forecaster - horizon(1)')
hold on
