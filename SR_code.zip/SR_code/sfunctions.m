function [qsr,wps,wps1,wps2,wps3,wps4,wps5,pseudosph,wpsph,wpsph1,wpsph2,wpsph3,wpsph4,wpsph5,logS,IntS,TsallisS,ES,GES,PSpectrum,CRPS,Quant,CLS,CSL,HS,LCS]=sfunctions(fore,h,yhat,thresh,a,aleph,k,d,beta,gamma,c,flag)
% This function compute the scoring function 
%
% Step 1: estimate the pdf/cdf (inverted cdf) 
[f,xi] = ksdensity(fore(h,:),'kernel','epanechnikov','function','cdf');
[f1,xi1] = ksdensity(fore(h,:),'kernel','epanechnikov','function','pdf');
[f2,xi2] = ksdensity(fore(h,:),'kernel','epanechnikov','function','icdf');
[f3,xi3] = ksdensity(yhat,'kernel','epanechnikov','function','pdf');
[f4,xi4] = ksdensity(yhat,'kernel','epanechnikov','function','cdf');
pdf = f1; 
cdf = f;
%cdf1 = f(:,50);  % fix cdf at the ?-th obs (normally the mean)
%pdf1 = f1(:,50); % Some change in names...
cdf2 = quantile(f2,a); % "               "
pdf2 = f3; 
%pdf21=pdf2(:,50);
cdf3 = f4;
[dpdf]=gradient(log(pdf)); 
%[dpdf1]=gradient(log(pdf1));  
[d2pdf]=gradient(gradient(log(pdf)));
u = aleph/2; l= 1-aleph/2;
% Step 2a: defines the indicators and preallocate the weights vectors
I= length(yhat); J=length(cdf(3:end)); 
w1=zeros(I,1); w2=zeros(J,1); w3=zeros(I,1); w4=zeros(J,1);
mu = mean(yhat);
%
% Step 2b: Defines the weights following the discretization in GR, formulas 16 - 17
u0 = 1;
u1 = pdf; 
u2 = 1-pdf./pdf(:,1);
u3 = cdf;
u4 = 1-cdf;
v0 = 1;
v1 = aleph.*(1-aleph);
v2 = (2.*aleph - 1).^2;
v3 = aleph.^2;
v4 = (1-aleph).^2;
for i=1:I
    w1(i) = (min(yhat)+i*range(yhat)/I)*u4(i); 
    w2(i) = (i/I)^2*v1;
end
for j = 1:J 
w3(j) = u1(j);
w4(j) = 1/(exp(gamma(1)*(cdf(j)-c(1))));%+ 1/(exp(gamma(2)*(cdf(j)-c(2))));
%w5(j) = indicat(yhat(j),thresh);
end
%  
% Step 2c: Define the Score functions
quadratic = 2*pdf - norm(pdf)^2;                                                             %Quadratic Score
wpower = ((pdf2./pdf).^(aleph-1) - 1)/(aleph-1) - ((pdf2./pdf).^(aleph-1)-1)./aleph;         %Weighted Power Score (General)
wp1 = -.5*(1+(pdf2./pdf)) + (pdf2./pdf);                                                   %Weighted Power Score (Beta=1)
wp2 = 1 - (pdf2./pdf) + (pdf2./pdf);                                                       %Weighted Power Score (Beta=0)
wp3 = 2*(2 - (pdf2./pdf) - (pdf2./pdf));                                                   %Weighted Power Score (Beta=1/2)
wp4 = log(pdf2./pdf);                                                                         %Weighted Power Score (Beta=1)
wp5 = (pdf2./pdf - 1) - .5*((pdf2./pdf));                                                  %Weighted Power Score (Beta=2)
pspherical = (pdf.^(aleph-1))/(norm(pdf).^aleph);                                              %Pseudo-spherical Score 
wpspherical = 1/(aleph-1)*((((pdf2./pdf).^(aleph-1))./(norm((pdf2./pdf),aleph))).^aleph-1);   %Pseudo-spherical Score
wpspherical1 = .5*(1-(pdf2./pdf)./(pdf2./pdf).^2);                                           %Pseudo-spherical Score (Beta =-1)
wpspherical2 = 1 - (pdf2./pdf).*exp(-(pdf2./pdf));                                         %Pseudo-spherical Score (Beta =0)
wpspherical3 = 2*(1-sqrt(pdf2./pdf).*(pdf2./pdf));                                          %Pseudo-spherical Score (Beta =1/2)
wpspherical4 = log(pdf./pdf);                                                                %Pseudo-spherical Score (Beta =1)
wpspherical5 = ((pdf2./pdf)./sqrt((pdf2./pdf)))-1;                                          %Pseudo-spherical Score (Beta =2)
logs = -(1/I)*(log(pdf));                                                                  %Logarithmic Score
int = (u-l) + (2/aleph)*indicat(yhat,l) + (2/aleph)*(1-indicat(yhat,l));                       %Interval Score
tsallis = k/(d-1) + (pdf.*(1-pdf).^(d-1));                                                  %Tsallis Score 
es = .5*norm((pdf - cdf))^beta - norm((mu - yhat))^beta;                                       %Energy score (with beta in (0,2))
ges = .5*norm((pdf - cdf),aleph)^beta - norm((mu - yhat),aleph)^beta;                          %Generalized Energy Score
pspectrum = - norm((pdf) - (exp(i*(pdf*toeplitz(pdf)*normpdf(length(pdf),0,1)))));             %Pseudo-Spectrum Score
ps = (cdf-indicat(yhat,thresh)).^2;                                                           %(Weighted)CRPS
qs = 2*(indicat(cdf2,a)-a)*(cdf2 - yhat);                                                      %(Weigthed) Quantile Score
crps = (range(yhat)/(length(yhat)-1))*sum(w1*ps);
quant = (1/(length(yhat)-1))*(w2'*qs);
cls = (1/I*std(yhat)).*(w3'.*(log(pdf2(3:end)) - (w3'.*log(pdf2(3:end)))));                          %Conditional Likelihood Score    
csl = (1/I*std(yhat)).*(log(pdf(3:end)*w4) + (log(1-((1/I).*(pdf(3:end)*(1-w4))))));                   %Censored Likelihood Score 
hs = (1/I*std(yhat)).*((log(pdf)-(dpdf)).^2 + 2*(d2pdf));                                %Hyvaarinen Score
lcs = -(log(cosh(dpdf))-log(cosh(pdf))) + (dpdf./pdf).*tanh(dpdf./pdf)...                %Log-Cosh Score
    + (d2pdf./pdf - (dpdf./pdf).^2).*tanh(tanh(dpdf./pdf));
%
% Step 3: Activate the indicator for Scoring the estimated model
% (discretized!) and delete the first and last observation (which normally
% are NaN or Inf)
if flag == 1
    qsr = quadratic;  qsr(1) = []; qsr(end) = []; 
    wps = wpower; wps(1) = []; wps(end) = [];
    wps1 = wp1; wps1(1) = []; wps1(end) = [];
    wps2 = wp2; wps2(1) = []; wps2(end) = [];
    wps3 = wp3; wps3(1) = []; wps3(end) = [];
    wps4 = wp4; wps4(1) = []; wps4(end) = [];
    wps5 = wp5; wps5(1) = []; wps5(end) = [];
    pseudosph = pspherical; pseudosph(1) = []; pseudosph(end) = [];
    wpsph = wpspherical; wpsph(1) = []; wpsph(end) = [];
    wpsph1 = wpspherical1; wpsph1(1) = []; wpsph1(end) = [];
    wpsph2 = wpspherical2; wpsph2(1) = []; wpsph2(end) = [];
    wpsph3 = wpspherical3; wpsph3(1) = []; wpsph3(end) = [];
    wpsph4 = wpspherical4; wpsph4(1) = []; wpsph4(end) = [];
    wpsph5 = wpspherical5; wpsph5(1) = []; wpsph5(end) = [];
    logS = logs; logS(1) = []; logS(end) = [];
    IntS = int;
    TsallisS = tsallis; TsallisS(1) = []; TsallisS(end) = [];
    ES = es;
    GES = ges;
    PSpectrum = pspectrum;
    CRPS = crps; 
    Quant = quant ;
    CLS = cls; CLS(1) = []; CLS(end) = [];
    CSL = csl;
    HS = hs;    HS(1) = []; HS(end) = [];
    LCS = lcs;  LCS(1) = []; LCS(end) = [];   
else
    qsr = repmat(0,length(quadratic),1);
    wps = repmat(0,length(wpower),1);
    wps1 = repmat(0,length(wp1),1);
    wps2 = repmat(0,length(wp2),1);
    wps3 = repmat(0,length(wp3),1);
    wps4 = repmat(0,length(wp4),1);
    wps5 = repmat(0,length(wp5),1);
    pseudosph = repmat(0,length(pspherical),1);
    wpsph = repmat(0,length(wpspherical),1);
    wpsph1 = repmat(0,length(wpspherical1),1);
    wpsph2 = repmat(0,length(wpspherical2),1);
    wpsph3 = repmat(0,length(wpspherical3),1);
    wpsph4 = repmat(0,length(wpspherical4),1);
    wpsph5 = repmat(0,length(wpspherical5),1);
    logS = repmat(0,length(logs),1);
    IntS = repmat(0,length(int),1);
    TsallisS = repmat(0,length(tsallis),1);
    ES = repmat(0,length(es),1);
    GES = repmat(0,length(ges),1);
    PSpectrum = repmat(0,length(pspectrum),1);
    CRPS = repmat(0,length(crps),1);  
    Quant = repmat(0,length(quant),1);
    CLS = repmat(0,length(cls),1);
    CSL = repmat(0,length(csl),1);
    HS = repmat(0,length(hs),1); 
    LCS = repmat(0,length(lcs),1);    
   
end
end