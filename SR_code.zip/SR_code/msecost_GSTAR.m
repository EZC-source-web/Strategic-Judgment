function [f,J]=msecost_GSTAR(PSI,y,X,W,q,m)

[T,nX] = size(X);
nW     = size(W,2);

[gamma1,gamma2,c] = getpar_GSTAR(PSI);

Z = [X W];
fX = zeros(T,m);
dfX = zeros(T,m);
for i=1:m
    fX(:,i)  = siglog(gamma1(i)*((q-c(i))<0) + gamma2(i)*((q-c(i))>0));
    dfX(:,i) = dsiglog(fX(:,i));
    Z        = [Z repmat(fX(:,i),1,nX).*X];
end
theta  = pinv(Z'*Z)*Z'*y;
alpha  = theta(1:nX);
if isempty(W)==1
    beta=[];
else
    beta   = theta(nX+1:nX+nW);
end
lambda = reshape(theta(nX+nW+1:end),nX,m);
if isempty(W)==1
    yhat   = X*alpha + sum((fX*lambda').*X,2);
else
    yhat   = X*alpha + W*beta + sum((fX*lambda').*X,2);
end; 
ehat   = y - yhat;
f      =  sum(ehat.^2)/T;

[ggamma1,ggamma2,gc] = gradGSTAR(PSI,X,q,lambda,dfX,m);

J = sum(-2*(repmat(ehat,1,3*m).*[ggamma1,ggamma2,gc])/T);