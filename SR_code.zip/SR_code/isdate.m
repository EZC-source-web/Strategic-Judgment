function [fis,fpt]= isdate(y,turnphase,sr)
% This function determines if a data point is a potential turning point
%
%SET THE VARIABLES
adf=zeros(turnphase*2,1); % preallocate for augmented date function 
i=turnphase+1;            % define the indicator i of y_t+i
fis=0;                    % declare the indicator of initial state
fpt=0;                    % declare the indicator potential turnig point
q=1;                      % declare an indicator q
qq=1;                     % declare a second indicator qq
%Start the algorithm: set the indicator for the case P-T GIVEN THE
%ESTIMATED SCORING RULE
while q<=turnphase*2+1
    if q~=i                             % if indicators of y_t+1 is different from y_t+k...
        adf(qq) = indicat((y(q)-y(i)),sr); % ...then y_t+1 <= y_t+k (that is y_t+1 - y_t+k <= 0); this event is called adf..
        qq=qq+1;                        % ...the indicator qq of which is augmented...
    end
    q=q+1;                              % consider all this for an augmented indicator q
end
p1=sum(adf);       % then, count the number of times that adf produces a one (the difference t_t+1 <= y_t+k <= 0)
if p1==turnphase*2 % The potential turning peak is setted if the cumulated peaks coincident with the turnphase
    fis=1;
    fpt=1;
end

%Repete the algorithm: set the indicator for the case T-P
q=1;
qq=1;
while q<=turnphase*2+1
    if q~=i;
        adf(qq) = indicat(y(i)-y(q),0); % in this case the indicator function is reversed
        qq=qq+1;
    end
       q=q+1;
end
p1=sum(adf);
if p1==turnphase*2
    fis=1;
    fpt=-1;
end