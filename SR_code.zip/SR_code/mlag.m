function out_matrix = mlag(in_matrix,l)
% this function takes as input a matrix and returns
% as output the l-th order shift-down version of the same matrix (i.e. the 2nd element of
% the new vector will have to be the 1st element of the original one, and so on).
% The two vectors must have the same size, so you must fill the first l 
% positions with NaN
c = size(in_matrix,2);
out_matrix = [zeros(l,c); in_matrix(1:end-l,:)];
end
