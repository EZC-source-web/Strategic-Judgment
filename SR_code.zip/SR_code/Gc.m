function [Gc] = Gc(gamma1, gamma2, h, eta, eta_t, s,T)
%This file compute the first derivatives of G on gamma2.


%Define the DERIVATIVES of Stukel function (formulas 73 and 74 in EZC)
dh11 = (gamma1^(-1))*(exp(gamma1.*abs(eta)) - 1) ; 
dh12 = eta ;
dh13 = (-1/gamma1)*log(1 - gamma1.*abs(eta)) ; 

dh21 = (-gamma2^(-1))*(exp(gamma2.*abs(eta)) - 1) ;
dh22 = eta ;
dh23 = (1/gamma2)*log(1 - gamma2.*abs(eta)) ; 
         
if gamma1 > 0
    dh1 = dh11;
elseif gamma1 == 0
    dh1 = dh12;
else dh1 = dh13;
end

if gamma2 > 0
   dh2 = dh21;
elseif gamma2 == 0
    dh2 = dh22 ;
else dh2 = dh23;
end
dh1=dh1(1,1:length(eta));
dh2=dh2(1,1:length(eta));

%Set the components of eq 
g = exp(-h.*(eta_t));
f = -h.*(eta_t);
df = ((s - 1) <=0).*(dh2') + (( s- 1) >=0).*(dh1');
dg = g.*df;
D2 = 1 + g.^2 + 2*g;
% Compute G_gamma1 (eq. 70)
Gc = (dg.*f.*df)./D2;

end