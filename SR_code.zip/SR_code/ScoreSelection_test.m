function [LM1, LM2, LM3, pval_LM1, pval_LM2, pval_LM3] = ScoreSelection_test(y_gstar, s,sr, Z, T, G, Ggamma1, Ggamma2, Gc)
%This function provides the LM test and p-value for test for logarithmic
%utility in nested scoring rule under GSTAR model 

%Define the matrix of regressors 
U = y_gstar;
p=size(Z,1);
O=ones(1,p);
ZG=Z'.*kron(O,G);
ZGgamma1=Z'.*kron(O,Ggamma1);
ZGgamma2=Z'.*kron(O,Ggamma2);
ZGc=Z'.*kron(O,Gc);
S = s.*sr;
%Define the matrix of covariates for the alternative of additive asymmetry
V = [ S, S.^2, S.^3 ];  %H_03'
V2 = [ S, S.^2];        %H_02'
V1 =  S ;               %H_01'

% THE NULL HP H_00' is V0 = [], that is an empty vector, so we can omit it

% Matrix of covariates UNDER THE NULL of NO ADDITITIVE ASYMMETRY. 
z01 = [   Z', ZG, ZGgamma1, ZGgamma2, ZGc]; 
z02 = [V1 Z', ZG, ZGgamma1, ZGgamma2, ZGc]; 
z03 = [V2 Z', ZG, ZGgamma1, ZGgamma2, ZGc];
% Matrix of covariates UNDER THE ALTERNATIVE. 
z1 = [V, Z', ZG];

%Regress and store the etimates and residuals under H0 - 
%NOTE: WE USE THE HETERO-ROBUST VERSION of
%the test while regressing U=[hat_u_tvgstar(t)] on z.
params01_ols = ols(U, z01);                     params02_ols = ols(U, z02);                 params03_ols = ols(U, z03);
%params01_est = [params0_ols(1:end).beta];      params02_est = [params02_ols(1:end).beta];  params03_est = [params03_ols(1:end).beta];
RES01 = [params01_ols(1:end).resid];            RES02 = [params02_ols(1:end).resid];        RES03 = [params03_ols(1:end).resid];
SE01 = [params01_ols(1:end).bstd];              SE02 = [params02_ols(1:end).bstd];          SE03 = [params03_ols(1:end).bstd];
SSR01 = sum(RES01.^2);                          SSR02 = sum(RES02.^2);                      SSR03 = sum(RES03.^2);
sigma201 = (1/T)*SSR01;                         sigma202 = (1/T)*SSR02;                     sigma203 = (1/T)*SSR03;                    
%Regress and store the etimates and residuals under H1
params1_ols = ols(U, z1);
%params1_est = [params1_ols(1:end).beta];
RES1 = [params1_ols(1:end).resid];
SE1 = [params1_ols(1:end).bstd];
SSR1 = sum(RES1.^2);
sigma21 = (1/T)*SSR1;

%F-statistic
n = size(z1,2);
LM1 = ((SSR01-SSR1)/(3*p))/(SSR1/(T-n-3*p)); pval_LM1 = 1-cdf('f', LM1, 3*p, T-n-3*p);
LM2 = ((SSR02-SSR1)/(3*p))/(SSR1/(T-n-3*p)); pval_LM2 = 1-cdf('f', LM2, 3*p, T-n-3*p);
LM3 = ((SSR03-SSR1)/(3*p))/(SSR1/(T-n-3*p)); pval_LM3 = 1-cdf('f', LM3, 3*p, T-n-3*p);
end