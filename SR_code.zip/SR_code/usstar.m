function [x,iseed] = usstar(iseed, nd)
% This function simulate a linear STAR(2) for the implementation of the BBQ 
%
randn('state',iseed);

xx=zeros(nd,1);
e = randn(nd,1);
u = e*.096;
i = 3;
gamma=1.5;
xx(1) = 0.7477;
xx(2) = 0.7477;


while i <= nd;
    xx(i) = .7477 + .47*xx(i-1) -.94*xx(i-2)*(1./(1+exp(gamma*(1.23-xx(i-1)))))  + ( - .2 - 1.24*xx(i-1) + .5490*xx(i-2) )*(1./(1+exp(gamma*(xx(i-1)-1.23)))) +  u(i);
    i = 1+i;
end
x=xx;

end