%% Script: Illustrate use of FanChart function

clear all; clc;
randn('state', 0);

% Generate artifical history and forecasts
T=204; % number of historical observations
H=1; % number of forecast periods
S=1000;
fore=randn(H,S);
for h=1:H
   fore(h,:)=(fore(h,:).*h)./100; 
end
hist=randn(100,0,1);

% Call fan chart function
[mat_quant]=FanChart(fore,hist,'2009q1', '2012q2');