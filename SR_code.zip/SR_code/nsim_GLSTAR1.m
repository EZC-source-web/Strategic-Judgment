function [y_gstar, u, sigma2_hat, sigma_hat] = nsim_GLSTAR1(T, y, y_nl, u_nl)
%This function simulate a time series following the Generalized Logistic
%function by Stukel (1988)
%
%The process is: y_t = phi_0 + phi_1 y_t-1 + phi_2*y_t-2 + theta_1 *G + eps.
%                G is an AR2 process
%
%Simulate the GSTAR(1) model like an additive model (a linear AR + a 
%Nonlinear AR) and compute estimated residuals, variance of
%estimated residuals and sd:
y_gstar=zeros(size(y,1),1);
u=zeros(size(y,1),1);
for i = 1 : T-2
    y_gstar(i) = y(i) + y_nl(i) ;
    u(i) =  u_nl(i);   %compute the estimated residuals as the sum 
                               %of the residuals of the two parts
end

sigma2_hat = (1/T)*sum((u.^2));  %compute the variance of the residuals 
sigma_hat = sqrt(sigma2_hat);    %compute the SD of the residuals

end