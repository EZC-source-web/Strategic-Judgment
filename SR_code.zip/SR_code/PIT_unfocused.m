clc;
clear
%IMPORT DATA
%importfile('/Users/emiliozanettichini/Desktop/WP/SR/Code/Data_q.xls');
%y=100*(log(IIP)-log(lag(IIP,1)));

%SIMULATE DATA
iseed = 12345;
randn('state', iseed);
[y, eps, phi, w, u_l] = sim_nAR(0, 0.9, -0.795, 265, 2);
x = lag(y,2);
R = 20;
pmax = 4;
qn = floor(R^(1/4));
h = 1;
T = length(y);

% Creates matrices to store the forecasts
densforecast = zeros(size(y,1),1)';
 
   %% COMPUTE PIT FROM AR
for i = R:(T-1)
roll_y = y(i-R+1:i,:);
roll_x = x(i-R+1:i,:);
  
l = mbic(roll_y,ones(R,1),roll_x, pmax);

one = ones(R-l+1,1);
for j = 1:l
    rgr = [one roll_x(l-j+1:end-j+1,:)];
end

[beta betaint e] = regress(roll_y(l:end,:),rgr);
sige = nw(e,qn);
        
z = [1 x(i+1,:) rgr(end,2:end-1)];
densforecast(1,i-R+1) = .5*(normcdf(y(i+1,1),z*beta,sige) + cdf('norm',y(i+1,1),0, 167/100));

end
%NS = 1:size(densforecast,2);
%densforecast = sum(cleanNaN(densforecast(:,l+1:end)),2)./NS(1,1:size(cleanNaN(densforecast(:,l+1:end)),2));
densforecast=densforecast(:,l+1:end);

%Figure 1
bin = 5; m = size(densforecast,2);
fn1 = figure;
hs = histc(densforecast,0:1/bin:1);
bar(0:1/bin:1,hs./m,'histc')
xlim([0 1])
ylim([0 .5])
title('PIT for Unfocused Forecaster - horizon(1)')
hold on
