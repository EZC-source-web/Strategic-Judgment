function [ff] = indicat(ddy,threshold)
% This function perform an Indicator function on the variable ddy
ff=0;
if ddy<=threshold;
ff=1;
end;

