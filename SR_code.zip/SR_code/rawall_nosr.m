function [bcp5,bct5,nbp,nbt]=rawall_nosr(y,turnphase,nd,phase,cycle,thresh)
% This function makes sure all restrictions are imposed and chooses turning points given the estimated SR.
% INPUTS: y : vector of data (which is initialised as zero vector for now)
%         turnphase : number of month (quarters) before the peak
%         nd : number of observations
%         phase : number of month (quarters) after the peak
%         cycle : number of complexvie months/quarter necessary for defying
%                a cycle.
%         thresh: the critical threshold for bypassing a phase/cycle restriction.
%
% OUTPUT: bcp5: business cycles peaks with turning point
%               at y_t >(<=) y_t+(-)k, k= 1,...K, K=2 (quartely) or K=5 (monthly);
%         bct5: business cycles toughs "                                        ";
%         nbp : number of peaks 
%         nbt : number of troughs ;
%*************************************************************************/
%STEP 0: SET THE INITIAL VALUE FOR INPUTS and COMPUTE SCORING RULES
bcp5 = [];  
bct5 = [];
i = turnphase + 1; 

% STEP 1: Look for the potential turning points and collect them 
while i <= nd-turnphase;   
    [fis,fpt] = isdate_nosr(y(i-turnphase:i+turnphase),turnphase); 
    if fis == 1 & (fpt==1);
        bcp5 = [bcp5;i];
        break
	    elseif fis == 1&(fpt==-1) 
            bct5 = [bct5;i];
            break
    end
    i=i+1;
end

% STEP 2: Now start the loop for imposing restrinctions
if rows(bcp5) + rows(bct5) == 0 % CASE 1: NO PEAKS (TROUGHTS) -->> Set to zero all the output variables  
nbp = 0; 
nbt = 0; 
bcp5 = 0; 
bct5 = 0;
else
    if fpt == 1              % OTHERWISE, VERYFY THE POSSIBILITY OF ONE PEAK  : the variables are setted
        j = bcp5;            % the indicator j is the peak...
        ltp = fpt;           % and the potential turnin point is also the last one
        i = j+1;
        jj = 0;
    else
        j = bct5;            % ...OR ONE TROUGHT
        ltp = fpt;
        i = j+1;
        jj = bct5;
    end
    while i<=nd-turnphase  %IN PARTICULAR, CHECK IF THE CONDITION STATED IN HARDING&PAGAN (formulas 2 and 3) HOLD
        [fis,fpt]=isdate_nosr(y(i-turnphase:i+turnphase),turnphase);             
        if rows(bcp5)+rows(bct5)<2;
            if fis==1&(fpt==1)&(i-j>=phase)&(ltp==-1)&(indicat(y(i)-y(jj),0)==0)
                bcp5=[bcp5;i];
                ltp=fpt;
                j=i;
            elseif fis==1&(fpt==-1)&(i-j>=phase)&(ltp==1)&(indicat(y(j)-y(i),0)==0)...
                    |(fis==1)&(fpt==-1)&(indicat(y(i)-y(j),0)==1)&(ltp==1)
                bct5=[bct5;i];
                ltp=fpt;
                jj=i;
            elseif fis==1&(fpt==1)&(ltp==1)&(indicat(y(j)-y(i),0)==1); 
                bcp5 = []; 
                bcp5=[bcp5;i];
                ltp=fpt;
                j=i;
            elseif fis==1&(fpt==-1)&(ltp==-1)&(indicat(y(i)-y(j),0)==1) 
                bct5=[];
                bct5=[bct5;i];
                ltp=fpt;
                jj=i;
            end
        else
            if fis==1&(fpt==1)&(i-jj>=phase)&(ltp==-1)&(i-j>=cycle)&(indicat(y(i)-y(jj),0)==0)
                bcp5=[bcp5;i];
                ltp=fpt;
                j=i;
                i=i+1;
                continue
            elseif fis==1&(fpt==1)&(ltp==-1)&(indicat(y(i)-y(jj),0)==0);
                if rows(bct5)>1;
                    if(y(i)<y(j))&(i-jj<phase)...
                            |(y(i)<y(j))&(i-jj<phase)&(i-j<cycle)...
                            |(y(i)<y(j))&(i-j<cycle)...
                            |((y(i)>=y(j))&(y(jj)<=y(bct5(rows(bct5)-1)))&(i-jj<phase))...    
                            |((y(i)>=y(j))&(y(jj)<=y(bct5(rows(bct5)-1)))&(i-jj<phase)&(i-j<cycle));
                    elseif(y(i)>=y(j))&(y(jj)>y(bct5(rows(bct5)-1)))&(i-jj<phase)...
                            |((y(i)>=y(j))&(y(jj)>y(bct5(rows(bct5)-1)))&(i-j<cycle));
                        bct5(rows(bct5),:)=[];  
                        if rows(bcp5)==1;
                            bcp5=[];
                        else
                            bcp5(rows(bcp5),:)=[];
                        end
                        bcp5=[bcp5;i];
                        ltp=fpt;
                        j=i;
                    elseif(y(i)>=y(j))&(y(jj)<=y(bct5(rows(bct5)-1)))&(i-j<cycle)
                        if rows(bct5)==2;
                            bct5(1,:)=[];
                        else
                            bct5t = bct5(rows(bct5));
                            bct5((rows(bct5)-1):rows(bct5),:) = [];
                            bct5 = [bct5;bct5t];
                        end
                        if rows(bcp5)==1;
                            bcp5=[];
                        else
                            bcp5(rows(bcp5),:)=[];
                        end
                        bcp5=[bcp5;i];
                        ltp=fpt;
                        j=i;
                    end
                elseif rows(bct5)==1
                    if(y(i)<y(j))&(i-jj<phase)...
                            (y(i)<y(j))&(i-jj<phase)&(i-j<cycle)...
                            |(y(i)<y(j))&(i-j<cycle)...
                            |((y(i)>=y(j))&(i-jj<phase)) ... 
                            |((y(i)>=y(j))&(i-jj<phase)&(i-j<cycle));
                    elseif(y(i)>=y(j))&(i-j<cycle)
                        bcp5=[];
                        bcp5=[bcp5;i];
                        ltp=fpt;
                        j=i;
                    end
                end
            elseif fis==1&(fpt==-1)&(i-j>=phase)&(ltp==1)&(i-jj>=cycle)&(indicat(y(j)-y(i),0)==0)...
                    |(fis==1)&(fpt==-1)&(y(i)-y(j)<-thresh)&(ltp==1)
                bct5=[bct5;i];
                ltp=fpt;
                jj=i;
                i=i+1;
                continue;
            elseif fis==1&(fpt==-1)&(ltp==1);
                if rows(bcp5) > 1;    
                    if(y(i)>y(jj))&(i-j<phase)...
                            |(y(i)>y(jj))&(i-j<phase)&(i-jj<cycle)...
                            |(y(i)>y(jj))&(i-jj<cycle)... 
                            |((y(i)<=y(jj))&(y(j)>=y(bcp5(rows(bcp5)-1)))&(i-j<phase))...   
                            |((y(i)<=y(j))&(y(j)>=y(bcp5(rows(bcp5)-1)))&(i-j<phase)&(i-jj<cycle));
                    elseif(y(i)<=y(jj))&(y(j)<y(bcp5(rows(bcp5)-1)))&(i-j<phase)...
                            |((y(i)<=y(j))&(y(j)<y(bcp5(rows(bcp5)-1)))&(i-jj<cycle));
                        bcp5(rows(bcp5),:)=[];
                        if rows(bct5)==1
                            bct5=[];
                        else
                            bct5(rows(bct5),:)=[];
                        end
                        bct5=[bct5;i];
                        ltp=fpt;
                        jj=i;
                    elseif(y(i)<=y(jj))&(y(j)>=y(bcp5(rows(bcp5)-1)))&(i-jj<cycle)
                        if rows(bcp5)==2
                            bcp5(1,:)=[];
                        else
                            bcp5t = bcp5(rows(bcp5));
                            bcp5((rows(bcp5)-1):rows(bcp5),:) = [];
                            bcp5 = [bcp5;bcp5t];
                        end
                        if rows(bct5)==1
                            bct5=[];
                        else
                            bct5(rows(bct5),:)=[];
                        end
                        bct5=[bct5;i];
                        ltp=fpt;
                        jj=i;
                    end
                elseif rows(bcp5)==1;
                    if(y(i)>y(jj))&(i-j<phase)...
                            |(y(i)>y(jj))&(i-j<phase)&(i-jj<cycle)...
                            |(y(i)>y(jj))&(i-jj<cycle)... 
                            |((y(i)<=y(jj))&(i-j<phase))...
                            |(y(i)<=y(j))&(i-j<phase)&(i-jj<cycle)
                    elseif(y(i)<=y(jj))&(i-jj<cycle)
                                    bct5=[];
                                    bct5=[bct5;i];
                                    ltp=fpt;
                                    jj=i;
                    end
                end
            elseif(fis==1)&(fpt==1)&(ltp==1)&(indicat(y(j)-y(i),0)==1);
                if rows(bcp5)==1;
                    bcp5=[];
                else
                    bcp5(rows(bcp5),:)=[];
                end
                bcp5=[bcp5;i];
                ltp=fpt;
                j=i;
            elseif fis==1&(fpt==-1)&(ltp==-1)&(indicat(y(i)-y(jj),0)==1)  
                if rows(bct5)==1;
                    bct5=[];
                else
                    bct5(rows(bct5),:)=[];
                end
                bct5=[bct5;i];
                ltp=fpt;
                jj=i;
            end
        end
        i=i+1;
    end
    if rows(bcp5)+rows(bct5)==1             % CASE 2: AT LEAST ONE PEAK (TROUGHT)
        bcp5=0;
        bct5=0;
    else
        if (bcp5(1,:) > bct5(1,:))
            j = bct5(1,:)-1;
            while j > 1
                if y(j,:)<y(bct5(1,:),:)
                    if rows(bct5)==1
                        bct5 =[];
                    else
                        bct5(1,:)=[];
                    end
                    break
                end
                j = j-1;
            end
        elseif (bcp5(1,:) < bct5(1,:))
            j = bcp5(1,:)-1;
            while j > 1
                if y(j,:) > y(bcp5(1,:),:)
                    if rows(bcp5) == 1
                        bcp5 = [];
                    else
                        bcp5(1,:)=[];
                    end
                    break
                end
                j = j-1;
            end
        end
    end
    if rows(bcp5)+rows(bct5) == 1;
        bcp5 = 0;
        bct5 = 0;
    else
        nbp=rows(bcp5);
        nbt=rows(bct5);
        if (bcp5(nbp,:) > bct5(nbt,:))
            j = bcp5(nbp,:)+1;
            while j < nd
                if y(j,:)>y(bcp5(nbp,:),:)
                    if rows(bcp5)>2
                        bcp5(rows(bcp5),:)=[];
                    else
                        bcp5=[];
                    end
                    break
                end
                j = j+1;
            end
        elseif (bcp5(nbp,:) < bct5(nbt,:))
            j = bct5(nbt,:)+1;
            while j < nd
                if y(j,:)<y(bct5(nbt,:),:)
                    if rows(bct5)>2
                        bct5(rows(bct5),:)=[];
                    else
                        bct5=[];
                    end
                    break
                end
                j = j+1;
            end
        end
    end
    nbp = rows(bcp5); 
    nbt = rows(bct5);
end