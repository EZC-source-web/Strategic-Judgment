function [Ggamma1] = Ggamma1(gamma1, gamma2, h, eta, eta_t, T)
%This file compute the first derivatives of G on gamma1.

%Define the DERIVATIVES of Stukel function (formulas 71 and 72 in EZC)
dh11 = (-1/(gamma1^2)).*(exp(abs(eta))- 1).*(abs(eta)-1) ; 
dh12 = zeros(1,T);
dh13 = (1/(gamma1^2)).*log(1 - gamma1.*abs(eta)) + abs(eta)./(1-gamma1.*(abs(eta))) ; 

dh21 = zeros(1,T);
dh22 = zeros(1,T);
dh23 = zeros(1,T); 
         
if gamma1 > 0
    dh1 = dh11;
elseif gamma1 == 0
    dh1 = dh12;
else dh1 = dh13;
end

if gamma2 > 0
   dh2 = dh21;
elseif gamma2 == 0
    dh2 = dh22 ;
else dh2 = dh23;
end
dh1=dh1(1,1:length(eta));
dh2=dh2(1,1:length(eta));

%Set the components of eq 70
g = exp(-h.*(eta_t));
f = -h.*(eta_t);
df = ((eta_t) <=0).*(dh2') + ((eta_t) >=0).*(dh1');
dg = g.*df;
D2 = 1 + g.^2 + 2*g;
% Compute G_gamma1 (eq. 70)
Ggamma1 = (dg.*f.*df)./D2;
end