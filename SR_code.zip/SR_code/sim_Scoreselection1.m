% This file perform the simulation of test for Logarithmic score under nesting SRs using (under GSTAR model)
%
clear
clc
iseed =123456;
randn('state', iseed);
%
%% STEP 0: Define the parameters
% Linear part
phi0 = 0.0;
phi1 = 0.4;
phi2 = -0.25;
% NON-Linear part
theta0 = 0.01;
theta1 = -0.3;
theta2 = 0.125;
% Slope parameters
gamma1 = 200;
gamma2 = 100;
% Other parameters
T = 300;
nsim = 1000;
alpha01 = 0.01; alpha05 = 0.05; alpha10 = 0.1;
sigerr = 1;
k=1;       % Scale constant 
d=100;     % Discard the first 1,...d simulations
H = 1;     % number of forecast periods
S = 100;   % number of simulations of the predictive density
%
%Scoring rules parameters
a=0.1;     % quantile
aleph=0.5; % alpha parameter for Weighted Pseudospherical and Power Scores
d=2;
beta=0.3;  % Beta parameter for Energy and Generalized Energy Scores

%
%Preallocate
Y = zeros(T - length([phi1 phi2]),nsim);
LM1=zeros(1,nsim); LM2=zeros(1, nsim); LM3=zeros(1, nsim);
P_LM1=zeros(1, nsim); P_LM2=zeros(1, nsim); P_LM3=zeros(1, nsim);
Beta = zeros(1, nsim);
Power = zeros(1, nsim);
%
%% STEP 1: INITIALIZATION
%Generate a linear AR in order to have w which is required for G and the
%Hessian
[y, eps, phi, w, u_l] = sim_nAR(phi0, phi1, phi2, T , sigerr);
p = T-length(y);
%Generate G
[theta, eta, s, c, eta_t, h, mu, G] = sim_G_glstar1(phi0, phi1, phi2, theta0, theta1, theta2, gamma1, gamma2, y, T);
%
%Build up the elements of the Score and Hessian (for whom I need only the
%parameters gamma1 gamma2, T, eta and eta_t which in turns are function
%of the Linear AR model previously defined.
[Ggamma1] = Ggamma1(gamma1, gamma2, h, eta, eta_t, T);
[Ggamma2] = Ggamma2(gamma1, gamma2, h, eta, eta_t, T);
[Gc] = Gc(gamma1, gamma2, h, eta, eta_t, T);
eps1 = eps(p+1:T);
%
%%  STEP 2: SIMULATE a LINEAR AR(2) process
for S=1:nsim    
% 
%Step 2.a: Generate a linear AR in order to have w which is required for G 
%and the Hessian 
[y, eps, phi, w, u_l] = sim_nAR(phi0, phi1, phi2, T , sigerr);
%
%Step 2.b: Generate the nonlinear function G
[theta, eta, s, c, eta_t, h, mu, G]=sim_G_glstar1(phi0, phi1, phi2, theta0, theta1, theta2, gamma1, gamma2, y, T);
%
%Step 2.c: Generate the NON-LINEAR part of the process in order to have w 
%which is required for G and the Hessian
[y_nl, u_nl] = sim_nlAR(theta0, theta, G, T, sigerr);

%Step 2.d: Define the GLSTAR1 as the sum of the Linear AR + Nonlinear AR 
% previously defined
[y_gstar, u, sigma2_hat, sigma_hat] = nsim_GLSTAR1(T, y, y_nl, u_nl);
bar_z = [lag(y,1), lag(y,2)]';
Z = [ones(1,length(bar_z))', bar_z']';
%
% STEP 2.e: DEFINE THE  GSTAR as the sum of the Linear AR + Nonlinear AR 
%previously defined
[y_gstar, u, sigma2_hat, sigma_hat] = nsim_GLSTAR1(T, y, y_nl, u_nl);
%
%% STEP 3: Compute the scoring rules
% Step 3.a: fix the parameters of the function
thresh = mean(y); 
gamma=1;          %threshold parameter for weigths of CLS/CSL
y=y_gstar;
flag=1; %Set flag=1 if you want activate the scoring rule, 0 otherwise
% Step 3.b: call the function
[qsr,wps,wps1,wps2,wps3,wps4,wps5,pseudosph,wpsph,wpsph1,wpsph2,wpsph3,wpsph4,wpsph5,logS,IntS,TsallisS,ES,GES,PSpectrum,crps,quant,CLS,CSL,HS,LCS]=scores(y,thresh,a,aleph,k,d,beta,gamma,c,flag,theta, H,S,T,iseed);
%[qsr,wps,wps1,wps2,wps3,wps4,wps5,pseudosph,wpsph,wpsph1,wpsph2,wpsph3,wpsph4,wpsph5,logS,IntS,TsallisS,ES,GES,PSpectrum,crps,quant,CLS,CSL,HS,LCS]=scorings(fore,h,yhat,thresh,a,aleph,k,d,beta,gamma,c,flag);
%SR=[qsr,wps,wps1,wps2,wps3,wps4,wps5,pseudosph,wpsph,wpsph1,wpsph2,wpsph3,wpsph4,wpsph5,logS,IntS,TsallisS,ES,GES,PSpectrum,CRPS,Quant,CLS,CSL,HS,LCS];
SR=[qsr,wps,wps1,wps2,wps3,wps4,wps5,pseudosph,wpsph,wpsph1,wpsph2,wpsph3,wpsph4,wpsph5,logS,IntS,TsallisS,ES,GES,PSpectrum,crps,quant,CLS,CSL,HS,LCS];
sr=SR(5); 
%[LM1, LM2, LM3, pval_LM1, pval_LM2, pval_LM3] = ScoreSelection_test(y_gstar, s,sr, Z, T, G, Ggamma1, Ggamma2, Gc);
[hat_z, h01, h02, h03, z_nl, S_LM1, S_LM2, S_LM3, pval_LM1, pval_LM2, pval_LM3]...
    = nLocalSLT_test(y_gstar, phi0, phi, theta0, theta, gamma1, gamma2, T, s, k, sr, c);
% Step 3.c: Store the Draws of the Statistic and p-value
Y(:,S) = y_gstar';
P_LM1(1,S) = pval_LM1;
P_LM2(1,S) = pval_LM2;
P_LM3(1,S) = pval_LM3;
end
%% STEP 5: STORE the RESULTS
Y(:,1:d)=[]; P_LM1(:,1:d)=[]; P_LM2(:,1:d)=[];P_LM3(:,1:d)=[]; %Discard the first d draws
%Define the Empirical P-value
EPval_LM1= mean(P_LM1); EPval_LM2= mean(P_LM2); EPval_LM3= mean(P_LM3);
%Define the Type II error (Beta) 
NS=1:size(Y,2);
Beta_P01_LM1=cumsum(P_LM1>alpha01)./NS; Beta_P01_LM2=cumsum(P_LM2>alpha01)./NS; Beta_P01_LM3=cumsum(P_LM3>alpha01)./NS; 
Beta_P05_LM1=cumsum(P_LM1>alpha05)./NS; Beta_P05_LM2=cumsum(P_LM2>alpha05)./NS; Beta_P05_LM3=cumsum(P_LM3>alpha05)./NS;
Beta_P10_LM1=cumsum(P_LM1>alpha10)./NS; Beta_P10_LM2=cumsum(P_LM2>alpha10)./NS; Beta_P10_LM3=cumsum(P_LM3>alpha10)./NS;
%  Power
Power_P01_LM1 = 1-Beta_P01_LM1;  Power_P01_LM2 = 1-Beta_P01_LM2; Power_P01_LM3 = 1-Beta_P01_LM3;
Power_P05_LM1 = 1-Beta_P05_LM1;  Power_P05_LM2 = 1-Beta_P05_LM2; Power_P05_LM3 = 1-Beta_P05_LM3;
Power_P10_LM1 = 1-Beta_P10_LM1;  Power_P10_LM2 = 1-Beta_P10_LM2; Power_P10_LM3 = 1-Beta_P10_LM3;
%  Empirical Beta
EBeta_P01_LM1 = mean(Beta_P01_LM1); EBeta_P01_LM2 = mean(Beta_P01_LM2); EBeta_P01_LM3 = mean(Beta_P01_LM3);
EBeta_P05_LM1 = mean(Beta_P05_LM1); EBeta_P05_LM2 = mean(Beta_P05_LM2); EBeta_P05_LM3 = mean(Beta_P05_LM3);
EBeta_P10_LM1 = mean(Beta_P10_LM1); EBeta_P10_LM2 = mean(Beta_P10_LM2); EBeta_P10_LM3 = mean(Beta_P10_LM3);
%  Empirical Power
EP_01_LM1 = mean(Power_P01_LM1); EP_01_LM2 = mean(Power_P01_LM2); EP_01_LM3 = mean(Power_P01_LM3);
EP_05_LM1 = mean(Power_P05_LM1); EP_05_LM2 = mean(Power_P05_LM2); EP_05_LM3 = mean(Power_P05_LM3);
EP_10_LM1 = mean(Power_P10_LM1); EP_10_LM2 = mean(Power_P10_LM2); EP_10_LM3 = mean(Power_P10_LM3);
%
%% STEP 6: RESULTS
disp('***************************************************************************************************')
disp('                                      Monte Carlo Results                                          ')
disp('***************************************************************************************************')
disp('---------------------------------------------------------------------------------------------------')
disp('                                          alpha = 0.01                                             ')
disp('---------------------------------------------------------------------------------------------------')
disp('               LM_01           ||            LM_02           ||            LM_03             ')
disp('-------------------------------||----------------------------||------------------------------')
disp(' Empirical  |  Emp.   |   Emp. ||   Emp   |  Emp.  |   Emp.  ||   Emp   |  Emp.  |   Emp.   ')
disp('  p-value   |  Beta   |  Power || p-value |  Beta  |  Power  || p-value |  Beta  |  Power   ')
disp('    ------  | ------  | ------ || ------  | ------ |  ------ || ------- | ------ |  ------  ')
disp( [EPval_LM1 EBeta_P01_LM1 EP_01_LM1 EPval_LM2 EBeta_P01_LM2 EP_01_LM2 EPval_LM3 EBeta_P01_LM3 EP_01_LM3])
disp('---------------------------------------------------------------------------------------------------')
disp('                                          alpha = 0.05                                             ')
disp('---------------------------------------------------------------------------------------------------')
disp('               LM_01           ||            LM_02           ||             LM_03             ')
disp('------------------------------ ||----------------------------||-------------------------------')
disp(' Empirical  |  Emp.   |   Emp. ||   Emp   |  Emp.  |   Emp.  ||  Emp    |  Emp.  |   Emp.  ')
disp('  p-value   |  Beta   |  Power || p-value |  Beta  |  Power  || p-value |  Beta  |  Power  ')
disp('    ------  | ------  | ------ || ------  | ------ |  ------ || ------- | ------ |  ------ ')
disp( [EPval_LM1 EBeta_P05_LM1 EP_05_LM1 EPval_LM2 EBeta_P05_LM2 EP_05_LM2 EPval_LM3 EBeta_P05_LM3 EP_05_LM3])
disp('---------------------------------------------------------------------------------------------------')
disp('                                        alpha = 0.10                                               ')
disp('---------------------------------------------------------------------------------------------------')
disp('               LM_01           ||           LM_02            ||            LM_03             ')
disp('------------------------------ ||----------------------------||------------------------------')
disp(' Empirical  |  Emp.   |   Emp. ||   Emp   |  Emp.  |  Emp.   ||   Emp   |  Emp.  |   Emp.   ')
disp('  p-value   |  Beta   |  Power || p-value |  Beta  | Power   || p-value |  Beta  |  Power   ')
disp('    ------  | ------  | ------ || ------  | ------ | ------  || ------- | ------ |  ------   ')
disp( [EPval_LM1 EBeta_P10_LM1 EP_10_LM1 EPval_LM2 EBeta_P10_LM2 EP_10_LM2 EPval_LM3 EBeta_P10_LM3 EP_10_LM3])
disp('----------------------------------------------------------------------------------------------------')
%
%Plot the power and the Beta
%figure(1)
%plot(NS, Beta_P01_LM1, NS, Power_P01_LM1,'-o');
%legend('\beta  for  LM1', 'Power  for  LM1');